const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function serverTimestamp(db) {
  // Retrieve FieldValue.serverTimestamp from the underlying compat firestore constructor
  return db.constructor.FieldValue
    ? db.constructor.FieldValue.serverTimestamp()
    : new Date();
}

function validPropertyPayload(ownerId, ts) {
  return {
    ownerId,
    title: "Oceanview Apartment 4B",
    type: "Rent",
    category: "Apartment",
    district: "Abdiaziz",
    location: "Abdiaziz, Near Lido Beach, Mogadishu",
    price: 450,
    beds: 3,
    baths: 2,
    area: 140,
    imageUrl: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00",
    description: "Solar power 24/7, secure parking, and continuous water supply.",
    verified: true,
    status: "published",
    createdAt: ts,
    updatedAt: ts,
  };
}

// --- DIRTY DOZEN & QUERY ALIGNMENT TESTS ---

test("1. Unauthenticated user cannot list or get properties", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("properties").where("status", "==", "published").get());
});

test("2. Authenticated user fails unfiltered property list query (rules are not filters)", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("properties").get());
});

test("3. Authenticated user can create own property and query published properties", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 1000);
  await assertSucceeds(
    aliceDb.collection("properties").doc("prop_1").set(validPropertyPayload(ALICE_UID, now))
  );
  await assertSucceeds(
    aliceDb.collection("properties").where("status", "==", "published").get()
  );
});

test("4. Identity spoofing on property create is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 1000);
  await assertFails(
    aliceDb.collection("properties").doc("prop_spoof").set(validPropertyPayload(BOB_UID, now))
  );
});

test("5. Ghost field injection on property create is rejected by hasOnly()", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 1000);
  await assertFails(
    aliceDb.collection("properties").doc("prop_ghost").set({
      ...validPropertyPayload(ALICE_UID, now),
      ghostAdminFlag: true,
    })
  );
});

test("6. Cross-user update or delete on another landlord's property fails", async () => {
  const now = new Date(Date.now() - 2000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("properties").doc("alice_prop").set(validPropertyPayload(ALICE_UID, now));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("properties").doc("alice_prop").update({
      price: 100,
      updatedAt: new Date(Date.now() - 500),
    })
  );
  await assertFails(bobDb.collection("properties").doc("alice_prop").delete());
});

test("7. Cross-user access to bookmarks, contracts, payments, and tickets is denied", async () => {
  const now = new Date(Date.now() - 2000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("users").doc(ALICE_UID).collection("contracts").doc("c1").set({
      userId: ALICE_UID,
      propertyTitle: "Villa 12",
      tenantName: "Amina Mohamed",
      paymentMethod: "EVC Plus",
      monthlyRent: 600,
      signaturePointsCount: 25,
      signaturePath: "M10,10 L50,40 L90,20",
      status: "signed",
      createdAt: now,
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("contracts").doc("c1").get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("contracts").where("userId", "==", ALICE_UID).get()
  );
});

test("8. Owner can create and query own digital contract, and cannot mutate signed contract", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 1000);
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("contracts").doc("c_valid").set({
      userId: ALICE_UID,
      propertyTitle: "Oceanview Apartment 4B",
      tenantName: "Eng. Jama Hassan",
      paymentMethod: "EVC Plus",
      monthlyRent: 450,
      signaturePointsCount: 18,
      signaturePath: "M12,20 L40,35 L88,18",
      status: "signed",
      createdAt: now,
    })
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("contracts").where("userId", "==", ALICE_UID).get()
  );
  // Signed contract must be immutable
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("contracts").doc("c_valid").delete()
  );
});

test("9. Forged empty signature or negative payment amount is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 1000);
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("contracts").doc("c_empty").set({
      userId: ALICE_UID,
      propertyTitle: "Oceanview Apartment 4B",
      tenantName: "Eng. Jama Hassan",
      paymentMethod: "EVC Plus",
      monthlyRent: 450,
      signaturePointsCount: 0,
      signaturePath: "",
      status: "signed",
      createdAt: now,
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("payments").doc("p_bad").set({
      userId: ALICE_UID,
      payerName: "Eng. Jama Hassan",
      propertyLabel: "Apt 3A",
      provider: "EVC Plus",
      phoneMasked: "+252 61 *** 1234",
      referenceCode: "#EVC-111",
      amount: -50,
      status: "completed",
      createdAt: now,
    })
  );
});

test("10. Maintenance ticket enforces terminal state lock once resolved", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const t0 = new Date(Date.now() - 3000);
  const t1 = new Date(Date.now() - 2000);
  const t2 = new Date(Date.now() - 1000);
  const ref = aliceDb.collection("users").doc(ALICE_UID).collection("maintenance_tickets").doc("t_1");

  await assertSucceeds(
    ref.set({
      userId: ALICE_UID,
      title: "Tubada Biyaha ee Musqusha",
      unitLabel: "Guri 4B, Abdiaziz",
      description: "U baahan bedelaad tubbada biyaha nidaamka matoorka.",
      fundiName: "Dahir Plumbing Service",
      status: "in_progress",
      createdAt: t0,
      updatedAt: t0,
    })
  );

  // Transition to resolved succeeds
  await assertSucceeds(ref.update({ status: "resolved", updatedAt: t1 }));

  // Subsequent update after terminal 'resolved' state must fail
  await assertFails(ref.update({ status: "open", updatedAt: t2 }));
});
