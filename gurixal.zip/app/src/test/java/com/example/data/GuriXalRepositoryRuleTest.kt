package com.example.data

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class GuriXalRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun createProperty_andObservePublished_succeedsForAuthenticatedLandlord() = runBlocking {
    signInTestUser(ALICE_EMAIL)
    val repo = GuriXalRepository(firestore, auth)

    val createRes =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo.createProperty(
          title = "Hodan Smart Villa",
          type = "Buy",
          category = "Villa",
          district = "Hodan",
          location = "Hodan, Digfer Road, Mogadishu",
          price = 150000.0,
          beds = 5L,
          baths = 4L,
          area = 350L,
          imageUrl = "https://images.unsplash.com/photo-1613977257363-707ba9348227",
          description = "Modern smart home villa in Hodan with 24/7 solar.",
          verified = true,
        )
      }
    assertTrue("Expected property creation to succeed: ${createRes.exceptionOrNull()}", createRes.isSuccess)
    val propId = createRes.getOrThrow()

    val observed =
      withTimeout(FLOW_TIMEOUT_MS) {
        repo.observePublishedProperties().first { list -> list.any { it.id == propId } }
      }
    assertTrue(observed.any { it.id == propId })
  }

  @Test
  fun signLeaseContract_crossUserAccess_failsWithPermissionDenied() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val aliceRepo = GuriXalRepository(firestore, auth)

    val contractId =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        aliceRepo
          .signLeaseContract(
            propertyTitle = "Oceanview Apartment 4B",
            tenantName = "Eng. Jama Hassan",
            paymentMethod = "EVC Plus",
            monthlyRent = 450.0,
            signaturePointsCount = 24L,
            signaturePath = "10.0,12.0;24.0,30.0;45.0,18.0",
          )
          .getOrThrow()
      }

    // Switch to Bob and verify cross-user get fails with PERMISSION_DENIED
    signInTestUser(BOB_EMAIL)
    val bobRepo = GuriXalRepository(firestore, auth)
    val crossRead =
      withTimeout(DEFAULT_TIMEOUT_MS) { bobRepo.getContractById(aliceUid, contractId) }
    assertTrue("Expected cross-user contract read to fail", crossRead.isFailure)
    val fsEx = crossRead.exceptionOrNull()?.unwrapFirestoreException()
    assertNotNull("Expected FirebaseFirestoreException", fsEx)
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
  }

  @Test
  fun recordPayment_andMaintenanceTicketLifecycle_succeedsForOwner() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val repo = GuriXalRepository(firestore, auth)

    val payResult =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo.recordMobilePayment(
          payerName = "Amina Mohamed",
          propertyLabel = "Villa 12 - Hodan",
          provider = "EVC Plus",
          rawPhone = "615551234",
          amount = 600.0,
        )
      }
    assertTrue(payResult.isSuccess)

    val ticketId =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo
          .createMaintenanceTicket(
            title = "Tubada Biyaha ee Musqusha",
            unitLabel = "Guri 4B, Abdiaziz",
            description = "U baahan bedelaad tubbada biyaha nidaamka matoorka.",
            fundiName = "Dahir Plumbing Service",
            status = "in_progress",
          )
          .getOrThrow()
      }

    val tickets =
      withTimeout(FLOW_TIMEOUT_MS) {
        repo.observeMaintenanceTickets(aliceUid).first { list -> list.any { it.id == ticketId } }
      }
    assertTrue(tickets.any { it.id == ticketId })

    val resolveResult =
      withTimeout(DEFAULT_TIMEOUT_MS) { repo.updateTicketStatus(ticketId, "resolved") }
    assertTrue(resolveResult.isSuccess)

    // Reopening a resolved ticket must fail due to terminal state lock
    val reopenResult =
      withTimeout(DEFAULT_TIMEOUT_MS) { repo.updateTicketStatus(ticketId, "open") }
    assertTrue("Expected terminal state lock to reject reopening resolved ticket", reopenResult.isFailure)
  }

  @Test
  fun observePublishedProperties_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
    auth.signOut()
    val repo = GuriXalRepository(firestore, auth)

    try {
      withTimeout(FLOW_TIMEOUT_MS) { repo.observePublishedProperties().first() }
      fail("Expected unauthenticated query to throw exception")
    } catch (e: Exception) {
      val fsEx = e.unwrapFirestoreException()
      assertNotNull("Expected wrapped FirebaseFirestoreException, got $e", fsEx)
      assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }
  }

  private companion object {
    const val ALICE_EMAIL = "alice_gurixal@test.com"
    const val BOB_EMAIL = "bob_gurixal@test.com"
    const val DEFAULT_TIMEOUT_MS = 5000L
    const val FLOW_TIMEOUT_MS = 4000L
  }
}
