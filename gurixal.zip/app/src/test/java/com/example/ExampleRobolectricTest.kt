package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ui.MortgageState
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read app_name string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("GuriXal", appName)
  }

  @Test
  fun `murabaha mortgage calculator matches prototype formula`() {
    val state = MortgageState(priceText = "120000", downPaymentText = "20", years = 10)
    assertEquals(1114.62, state.estimatedMonthlyUsd, 0.05)
  }
}
