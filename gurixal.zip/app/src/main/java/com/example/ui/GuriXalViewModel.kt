package com.example.ui

import android.util.Log
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Bookmark
import com.example.data.GuriXalRepository
import com.example.data.LeaseContract
import com.example.data.MaintenanceTicket
import com.example.data.PaymentRecord
import com.example.data.PropertyListing
import com.example.data.UiState
import kotlin.math.pow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class BottomNavDestination {
  EXPLORE,
  CONTRACT,
  DASHBOARD,
  ACCOUNT,
}

enum class PillarTab {
  FIND,
  BUY,
  RENT,
  MANAGE,
}

data class ToastBanner(val id: Long, val title: String, val message: String)

data class FilterConfig(
  val searchQuery: String = "",
  val selectedDistrict: String = "all",
  val selectedCategory: String = "All",
  val bookmarksOnly: Boolean = false,
)

data class MortgageState(
  val priceText: String = "120000",
  val downPaymentText: String = "20",
  val years: Int = 10,
) {
  val estimatedMonthlyUsd: Double
    get() {
      val price = priceText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
      val downPct = downPaymentText.toDoubleOrNull()?.coerceIn(0.0, 99.0) ?: 0.0
      val principal = price * (1.0 - (downPct / 100.0))
      if (principal <= 0.0) return 0.0
      val annualRate = 0.07 // 7% Murabaha profit rate
      val monthlyRate = annualRate / 12.0
      val totalPayments = (years.coerceIn(1, 30) * 12).toDouble()
      val factor = (1.0 + monthlyRate).pow(totalPayments)
      return (principal * monthlyRate * factor) / (factor - 1.0)
    }
}

class GuriXalViewModel(
  private val repository: GuriXalRepository,
  val currentUserId: String,
  val currentUserName: String,
  val currentUserEmail: String,
) : ViewModel() {

  private val _bottomDestination = MutableStateFlow(BottomNavDestination.EXPLORE)
  val bottomDestination: StateFlow<BottomNavDestination> = _bottomDestination.asStateFlow()

  private val _pillarTab = MutableStateFlow(PillarTab.FIND)
  val pillarTab: StateFlow<PillarTab> = _pillarTab.asStateFlow()

  private val _filters = MutableStateFlow(FilterConfig())
  val filters: StateFlow<FilterConfig> = _filters.asStateFlow()

  private val _mortgage = MutableStateFlow(MortgageState())
  val mortgage: StateFlow<MortgageState> = _mortgage.asStateFlow()

  private val _selectedProperty = MutableStateFlow<PropertyListing?>(null)
  val selectedProperty: StateFlow<PropertyListing?> = _selectedProperty.asStateFlow()

  private val _showPaymentModal = MutableStateFlow(false)
  val showPaymentModal: StateFlow<Boolean> = _showPaymentModal.asStateFlow()

  private val _showContractModal = MutableStateFlow(false)
  val showContractModal: StateFlow<Boolean> = _showContractModal.asStateFlow()

  private val _showAddPropertyModal = MutableStateFlow(false)
  val showAddPropertyModal: StateFlow<Boolean> = _showAddPropertyModal.asStateFlow()

  private val _showNewTicketModal = MutableStateFlow(false)
  val showNewTicketModal: StateFlow<Boolean> = _showNewTicketModal.asStateFlow()

  private val _showFilterModal = MutableStateFlow(false)
  val showFilterModal: StateFlow<Boolean> = _showFilterModal.asStateFlow()

  private val _isProcessingPayment = MutableStateFlow(false)
  val isProcessingPayment: StateFlow<Boolean> = _isProcessingPayment.asStateFlow()

  private val _toastBanner = MutableStateFlow<ToastBanner?>(null)
  val toastBanner: StateFlow<ToastBanner?> = _toastBanner.asStateFlow()

  // Two-tier Kotlin Flow error handling on all Firestore streams
  val propertiesState: StateFlow<UiState<List<PropertyListing>>> =
    repository
      .observePublishedProperties()
      .map<List<PropertyListing>, UiState<List<PropertyListing>>> { UiState.Success(it) }
      .catch { error ->
        Log.w(TAG, "Error observing properties", error)
        emit(UiState.Error(error.message ?: "Failed to load properties"))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
      )

  val bookmarksState: StateFlow<UiState<List<Bookmark>>> =
    repository
      .observeBookmarks(currentUserId)
      .map<List<Bookmark>, UiState<List<Bookmark>>> { UiState.Success(it) }
      .catch { error ->
        Log.w(TAG, "Error observing bookmarks", error)
        emit(UiState.Error(error.message ?: "Failed to load bookmarks"))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
      )

  val contractsState: StateFlow<UiState<List<LeaseContract>>> =
    repository
      .observeContracts(currentUserId)
      .map<List<LeaseContract>, UiState<List<LeaseContract>>> { UiState.Success(it) }
      .catch { error ->
        Log.w(TAG, "Error observing contracts", error)
        emit(UiState.Error(error.message ?: "Failed to load contracts"))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
      )

  val paymentsState: StateFlow<UiState<List<PaymentRecord>>> =
    repository
      .observePayments(currentUserId)
      .map<List<PaymentRecord>, UiState<List<PaymentRecord>>> { UiState.Success(it) }
      .catch { error ->
        Log.w(TAG, "Error observing payments", error)
        emit(UiState.Error(error.message ?: "Failed to load payments"))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
      )

  val ticketsState: StateFlow<UiState<List<MaintenanceTicket>>> =
    repository
      .observeMaintenanceTickets(currentUserId)
      .map<List<MaintenanceTicket>, UiState<List<MaintenanceTicket>>> { UiState.Success(it) }
      .catch { error ->
        Log.w(TAG, "Error observing maintenance tickets", error)
        emit(UiState.Error(error.message ?: "Failed to load tickets"))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
      )

  init {
    viewModelScope.launch { repository.seedInitialMogadishuDataIfEmpty(currentUserId) }
  }

  fun selectBottomDestination(destination: BottomNavDestination) {
    _bottomDestination.value = destination
    if (destination == BottomNavDestination.DASHBOARD) {
      _pillarTab.value = PillarTab.MANAGE
    } else if (destination == BottomNavDestination.EXPLORE && _pillarTab.value == PillarTab.MANAGE) {
      _pillarTab.value = PillarTab.FIND
    }
  }

  fun selectPillarTab(tab: PillarTab) {
    _pillarTab.value = tab
    if (tab == PillarTab.MANAGE) {
      _bottomDestination.value = BottomNavDestination.DASHBOARD
    } else {
      _bottomDestination.value = BottomNavDestination.EXPLORE
    }
  }

  fun navigateBackToExplore() {
    _bottomDestination.value = BottomNavDestination.EXPLORE
    _pillarTab.value = PillarTab.FIND
  }

  fun updateSearchQuery(query: String) {
    _filters.update { it.copy(searchQuery = query) }
  }

  fun selectDistrict(district: String) {
    _filters.update { it.copy(selectedDistrict = district) }
  }

  fun applyFilters(category: String, bookmarksOnly: Boolean) {
    _filters.update { it.copy(selectedCategory = category, bookmarksOnly = bookmarksOnly) }
    _showFilterModal.value = false
    showToast("Sefeeyaha", "Sefeeyaha hantida waa la dhaqangeliyay.")
  }

  fun updateMortgagePrice(value: String) {
    _mortgage.update { it.copy(priceText = value.filter { ch -> ch.isDigit() || ch == '.' }) }
  }

  fun updateMortgageDown(value: String) {
    _mortgage.update { it.copy(downPaymentText = value.filter { ch -> ch.isDigit() || ch == '.' }) }
  }

  fun updateMortgageYears(years: Int) {
    _mortgage.update { it.copy(years = years) }
  }

  fun openPropertyDetail(property: PropertyListing) {
    _selectedProperty.value = property
  }

  fun closePropertyDetail() {
    _selectedProperty.value = null
  }

  fun openPaymentSheetForSelected() {
    _showPaymentModal.value = true
  }

  fun closePaymentModal() {
    if (!_isProcessingPayment.value) {
      _showPaymentModal.value = false
    }
  }

  fun openContractModal() {
    _showContractModal.value = true
  }

  fun closeContractModal() {
    _showContractModal.value = false
  }

  fun openAddPropertyModal() {
    _showAddPropertyModal.value = true
  }

  fun closeAddPropertyModal() {
    _showAddPropertyModal.value = false
  }

  fun openNewTicketModal() {
    _showNewTicketModal.value = true
  }

  fun closeNewTicketModal() {
    _showNewTicketModal.value = false
  }

  fun openFilterModal() {
    _showFilterModal.value = true
  }

  fun closeFilterModal() {
    _showFilterModal.value = false
  }

  fun toggleBookmark(property: PropertyListing, isCurrentlyBookmarked: Boolean) {
    viewModelScope.launch {
      val result =
        repository.toggleBookmark(
          propertyId = property.id,
          propertyTitle = property.title,
          currentlyBookmarked = isCurrentlyBookmarked,
        )
      result
        .onSuccess { added ->
          showToast(
            "Hantida",
            if (added) "Waa lagu daray liiskaaga kaydka."
            else "Waa laga saaray liiska kaydka.",
          )
        }
        .onFailure { err -> showToast("Cilad", err.localizedMessage ?: "Ma suurtogelin kaydintu.") }
    }
  }

  fun submitMobilePayment(provider: String, phone: String) {
    val prop = _selectedProperty.value
    val amount = prop?.price ?: 600.0
    val propTitle = prop?.title ?: "GuriXal Verified Unit"
    val payer = currentUserName.ifBlank { "GuriXal Verified Tenant" }

    if (phone.filter { it.isDigit() }.length < 6) {
      showToast("Lambarka", "Fadlan geli lambar sax ah oo Soomaaliya ah (+252).")
      return
    }

    viewModelScope.launch {
      _isProcessingPayment.value = true
      delay(1100L) // Brief USSD prompt confirmation cadence
      val res =
        repository.recordMobilePayment(
          payerName = payer,
          propertyLabel = propTitle,
          provider = provider,
          rawPhone = phone,
          amount = amount,
        )
      _isProcessingPayment.value = false
      res
        .onSuccess { refCode ->
          _showPaymentModal.value = false
          _selectedProperty.value = null
          showToast("Guul ($refCode)", "Lacag bixinta via $provider waa la ansixiyay!")
        }
        .onFailure { err ->
          showToast("Cilad", err.localizedMessage ?: "Lacag bixintu ma guulaysan.")
        }
    }
  }

  fun signAndSaveContract(
    propertyTitle: String,
    paymentMethod: String,
    monthlyRent: Double,
    strokes: List<List<Offset>>,
  ) {
    val allPoints = strokes.flatten()
    if (allPoints.size < 4) {
      showToast("Saxeexa", "Fadlan ku sawir saxeexaaga sanduuqa hoose ka hor intaadan kaydin.")
      return
    }
    val serializedPath =
      strokes
        .take(25)
        .joinToString("|") { stroke ->
          stroke
            .take(35)
            .joinToString(";") { pt -> "${pt.x.toInt()},${pt.y.toInt()}" }
        }
        .take(3800)

    val tenant = currentUserName.ifBlank { "GuriXal Tenant" }

    viewModelScope.launch {
      val res =
        repository.signLeaseContract(
          propertyTitle = propertyTitle.ifBlank { "Oceanview Apartment 4B" },
          tenantName = tenant,
          paymentMethod = paymentMethod,
          monthlyRent = monthlyRent.coerceAtLeast(50.0),
          signaturePointsCount = allPoints.size.toLong(),
          signaturePath = serializedPath,
        )
      res
        .onSuccess {
          _showContractModal.value = false
          showToast("Heshiiska", "Heshiiska Digitaalka ah waa la saxeexay oo waa la kaydiyay!")
        }
        .onFailure { err ->
          showToast("Cilad", err.localizedMessage ?: "Kaydinta heshiisku ma guulaysan.")
        }
    }
  }

  fun publishNewProperty(
    title: String,
    type: String,
    category: String,
    district: String,
    priceText: String,
    bedsText: String,
    bathsText: String,
    areaText: String,
    description: String,
  ) {
    val cleanTitle = title.trim()
    val price = priceText.toDoubleOrNull() ?: 0.0
    val area = (areaText.toLongOrNull() ?: 120L).coerceAtLeast(15L)
    val beds = (bedsText.toLongOrNull() ?: if (category == "Land") 0L else 3L).coerceIn(0L, 30L)
    val baths = (bathsText.toLongOrNull() ?: if (category == "Land") 0L else 2L).coerceIn(0L, 30L)

    if (cleanTitle.length < 3 || price <= 0.0) {
      showToast("Macluumaad Dhiman", "Fadlan geli magaca hantida iyo qiime sax ah.")
      return
    }

    val imageForCategory =
      when (category) {
        "Villa" ->
          "https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=800&q=80"
        "Land" ->
          "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=800&q=80"
        else ->
          "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80"
      }

    viewModelScope.launch {
      val res =
        repository.createProperty(
          title = cleanTitle,
          type = type,
          category = category,
          district = district,
          location = "$district, Mogadishu",
          price = price,
          beds = beds,
          baths = baths,
          area = area,
          imageUrl = imageForCategory,
          description =
            description.ifBlank {
              "Hanti sharciyeysan oo ku taalla $district, Muqdisho. Koronto Solar 24/7 iyo amni sugan."
            },
          verified = true,
        )
      res
        .onSuccess {
          _showAddPropertyModal.value = false
          selectPillarTab(PillarTab.FIND)
          showToast("Waad ku guulaysatay!", "Hantida cusub waa la hubiyay oo waa la nashriyay.")
        }
        .onFailure { err ->
          showToast("Cilad", err.localizedMessage ?: "Nashrinta hantidu ma guulaysan.")
        }
    }
  }

  fun submitMaintenanceTicket(
    title: String,
    unitLabel: String,
    description: String,
    fundiName: String,
  ) {
    if (title.trim().length < 3 || description.trim().length < 5) {
      showToast("Macluumaad Dhiman", "Fadlan geli cinwaanka iyo faahfaahinta ciladda.")
      return
    }
    viewModelScope.launch {
      val res =
        repository.createMaintenanceTicket(
          title = title,
          unitLabel = unitLabel.ifBlank { "Hodan Unit 2A" },
          description = description,
          fundiName = fundiName.ifBlank { "Dahir Plumbing Service" },
          status = "open",
        )
      res
        .onSuccess {
          _showNewTicketModal.value = false
          showToast("Codsi Dayactir", "Tigidhka dayactirka waa loo gudbiyay Fundiga.")
        }
        .onFailure { err ->
          showToast("Cilad", err.localizedMessage ?: "Gudbinta dayactirku ma guulaysan.")
        }
    }
  }

  fun advanceMaintenanceStatus(ticket: MaintenanceTicket) {
    val nextStatus =
      when (ticket.status) {
        "open" -> "in_progress"
        "in_progress" -> "resolved"
        else -> return
      }
    viewModelScope.launch {
      repository
        .updateTicketStatus(ticket.id, nextStatus)
        .onSuccess {
          val label = if (nextStatus == "resolved") "Waa la xalliyay (Resolved)" else "In Progress"
          showToast("Dayactirka", "${ticket.title} -> $label")
        }
        .onFailure { err ->
          showToast("Cilad", err.localizedMessage ?: "Cusboonaysiintu ma guulaysan.")
        }
    }
  }

  fun showToast(title: String, message: String) {
    val id = System.currentTimeMillis()
    _toastBanner.value = ToastBanner(id = id, title = title, message = message)
    viewModelScope.launch {
      delay(3000L)
      if (_toastBanner.value?.id == id) {
        _toastBanner.value = null
      }
    }
  }

  private companion object {
    const val TAG = "GuriXalVM"
    const val STOP_TIMEOUT_MILLIS = 5000L
  }
}
