package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.Bookmark
import com.example.data.LeaseContract
import com.example.data.MaintenanceTicket
import com.example.data.PaymentRecord
import com.example.data.PropertyListing
import com.example.ui.theme.LocalGuriXalColors
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun ManageDashboardContent(
  properties: List<PropertyListing>,
  payments: List<PaymentRecord>,
  tickets: List<MaintenanceTicket>,
  onOpenAddProperty: () -> Unit,
  onOpenNewTicket: () -> Unit,
  onCallFundi: (MaintenanceTicket) -> Unit,
  onAdvanceTicketStatus: (MaintenanceTicket) -> Unit,
  modifier: Modifier = Modifier,
) {
  val extraColors = LocalGuriXalColors.current
  val totalRevenue = payments.sumOf { it.amount }
  val activeUnits = properties.size.coerceAtLeast(1)
  val openTicketsCount = tickets.count { it.status != "resolved" }
  val pendingRent = 650.0

  Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
    // 1. Landlord Financial Overview Gradient Card
    Card(
      shape = RoundedCornerShape(26.dp),
      elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
      modifier = Modifier.fillMaxWidth().testTag("landlord_overview_card"),
    ) {
      Column(
        modifier =
          Modifier.fillMaxWidth()
            .background(
              Brush.linearGradient(
                listOf(
                  extraColors.headerGradientStart,
                  MaterialTheme.colorScheme.primary,
                  extraColors.headerGradientEnd,
                )
              )
            )
            .padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Top,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Surface(
              shape = CircleShape,
              color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.14f),
            ) {
              Text(
                text = stringResource(R.string.landlord_dashboard_badge).uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
              )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = formatUsd(totalRevenue, decimals = 2),
              style = MaterialTheme.typography.displaySmall,
              color = MaterialTheme.colorScheme.onPrimary,
            )
            Text(
              text = stringResource(R.string.landlord_income_caption),
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f),
            )
          }

          Button(
            onClick = onOpenAddProperty,
            shape = RoundedCornerShape(16.dp),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = extraColors.goldAccent,
                contentColor = extraColors.onGoldAccent,
              ),
            modifier = Modifier.height(48.dp).testTag("add_property_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.Add,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = stringResource(R.string.btn_add_property),
              style = MaterialTheme.typography.labelMedium,
            )
          }
        }

        Spacer(modifier = Modifier.height(18.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.18f))
        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          DashboardMiniStat(
            label = stringResource(R.string.stat_active_units),
            value = "$activeUnits Units",
            valueColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.weight(1f),
          )
          DashboardMiniStat(
            label = stringResource(R.string.stat_pending_rent),
            value = formatUsd(pendingRent),
            valueColor = extraColors.goldAccent,
            modifier = Modifier.weight(1f),
          )
          DashboardMiniStat(
            label = stringResource(R.string.stat_open_tickets),
            value = "$openTicketsCount Ka jira",
            valueColor = extraColors.warningAmber,
            modifier = Modifier.weight(1f),
          )
        }
      }
    }

    // 2. Mobile Money Live Sync Payment Ledger
    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = BorderStroke(1.dp, extraColors.cardBorder),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = stringResource(R.string.payments_section_title).uppercase(),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Surface(
            shape = CircleShape,
            color = extraColors.verifiedGreenContainer,
          ) {
            Text(
              text = stringResource(R.string.live_sync_badge),
              style = MaterialTheme.typography.labelSmall,
              color = extraColors.verifiedGreen,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            )
          }
        }

        if (payments.isEmpty()) {
          Text(
            text = "Weli wax lacag bixin ah lama diiwaangelin.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        } else {
          payments.take(6).forEach { pay ->
            PaymentLedgerRow(payment = pay)
          }
        }
      }
    }

    // 3. Maintenance Tickets Tracker
    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = BorderStroke(1.dp, extraColors.cardBorder),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = stringResource(R.string.maintenance_section_title).uppercase(),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
          )
          TextButton(
            onClick = onOpenNewTicket,
            modifier = Modifier.testTag("open_new_ticket_button"),
          ) {
            Text(
              text = stringResource(R.string.btn_new_ticket),
              style = MaterialTheme.typography.labelMedium,
            )
          }
        }

        tickets.forEach { ticket ->
          MaintenanceTicketItem(
            ticket = ticket,
            onCallFundi = { onCallFundi(ticket) },
            onAdvanceStatus = { onAdvanceTicketStatus(ticket) },
          )
        }
      }
    }
  }
}

@Composable
private fun DashboardMiniStat(
  label: String,
  value: String,
  valueColor: androidx.compose.ui.graphics.Color,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.1f),
    modifier = modifier,
  ) {
    Column(
      modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.76f),
        maxLines = 1,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = valueColor,
        maxLines = 1,
      )
    }
  }
}

@Composable
private fun PaymentLedgerRow(payment: PaymentRecord) {
  val extraColors = LocalGuriXalColors.current
  val (badgeText, badgeColor) =
    when (payment.provider) {
      "EVC Plus" -> "EVC" to extraColors.evcBadge
      "Premier Wallet" -> "P" to extraColors.premierBadge
      "SAHAL" -> "S" to extraColors.sahalBadge
      "Zaad" -> "Z" to extraColors.zaadBadge
      else -> "GX" to MaterialTheme.colorScheme.primary
    }

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.padding(12.dp).fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f),
      ) {
        Box(
          modifier = Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(badgeColor),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = badgeText,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onPrimary,
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = payment.payerName,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = "${payment.propertyLabel} • ${payment.referenceCode}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
      Text(
        text = "+${formatUsd(payment.amount, decimals = 2)}",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = extraColors.verifiedGreen,
      )
    }
  }
}

@Composable
private fun MaintenanceTicketItem(
  ticket: MaintenanceTicket,
  onCallFundi: () -> Unit,
  onAdvanceStatus: () -> Unit,
) {
  val extraColors = LocalGuriXalColors.current
  val (statusLabel, badgeBg, badgeFg) =
    when (ticket.status) {
      "resolved" ->
        Triple("Resolved", extraColors.verifiedGreenContainer, extraColors.verifiedGreen)
      "in_progress" ->
        Triple("In Progress", extraColors.warningAmberContainer, extraColors.warningAmber)
      else ->
        Triple(
          "Open",
          MaterialTheme.colorScheme.primaryContainer,
          MaterialTheme.colorScheme.primary,
        )
    }

  Surface(
    shape = RoundedCornerShape(18.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, extraColors.cardBorder),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(badgeFg))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = ticket.title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
          )
        }
        Surface(shape = RoundedCornerShape(6.dp), color = badgeBg) {
          Text(
            text = statusLabel,
            style = MaterialTheme.typography.labelSmall,
            color = badgeFg,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
          )
        }
      }

      Text(
        text = ticket.description,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )

      HorizontalDivider(color = extraColors.cardBorder)

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "Fundi: ${ticket.fundiName}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.weight(1f),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          if (ticket.status != "resolved") {
            OutlinedButton(
              onClick = onAdvanceStatus,
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.height(48.dp).testTag("advance_ticket_${ticket.id}"),
            ) {
              Text(
                text = if (ticket.status == "open") "Start" else "Resolve",
                style = MaterialTheme.typography.labelSmall,
              )
            }
          }
          Button(
            onClick = onCallFundi,
            shape = RoundedCornerShape(10.dp),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
              ),
            modifier = Modifier.height(48.dp).testTag("call_fundi_${ticket.id}"),
          ) {
            Icon(
              imageVector = Icons.Filled.Call,
              contentDescription = null,
              modifier = Modifier.size(14.dp),
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = stringResource(R.string.btn_call_fundi),
              style = MaterialTheme.typography.labelSmall,
            )
          }
        }
      }
    }
  }
}

@Composable
fun DigitalContractsHubView(
  contracts: List<LeaseContract>,
  onOpenSignContractModal: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val extraColors = LocalGuriXalColors.current
  val dateFormatter = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US)

  Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
    Card(
      shape = RoundedCornerShape(26.dp),
      colors =
        CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Filled.Draw,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(26.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = stringResource(R.string.contract_title),
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Text(
              text = stringResource(R.string.contract_subtitle),
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
            )
          }
        }
        Button(
          onClick = onOpenSignContractModal,
          shape = RoundedCornerShape(14.dp),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = extraColors.goldAccent,
              contentColor = extraColors.onGoldAccent,
            ),
          modifier = Modifier.fillMaxWidth().height(50.dp).testTag("new_digital_contract_button"),
        ) {
          Icon(imageVector = Icons.Filled.Description, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.contract_new_btn),
            style = MaterialTheme.typography.labelLarge,
          )
        }
      }
    }

    Text(
      text = stringResource(R.string.contract_history_title).uppercase(),
      style = MaterialTheme.typography.labelMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    if (contracts.isEmpty()) {
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, extraColors.cardBorder),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(
          modifier = Modifier.padding(28.dp).fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Icon(
            imageVector = Icons.Filled.Description,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(36.dp),
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Weli wax heshiis dhijitaal ah lama saxeexin.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    } else {
      contracts.forEach { contract ->
        val dateText =
          contract.createdAt?.toDate()?.let { dateFormatter.format(it) } ?: "Just signed"
        Card(
          shape = RoundedCornerShape(22.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, extraColors.cardBorder),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = contract.propertyTitle,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
              )
              Surface(shape = CircleShape, color = extraColors.verifiedGreenContainer) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    imageVector = Icons.Filled.Verified,
                    contentDescription = null,
                    tint = extraColors.verifiedGreen,
                    modifier = Modifier.size(13.dp),
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = "SIGNED",
                    style = MaterialTheme.typography.labelSmall,
                    color = extraColors.verifiedGreen,
                  )
                }
              }
            }

            Text(
              text =
                "Kirayste: ${contract.tenantName} • ${formatUsd(contract.monthlyRent)}/mo via ${contract.paymentMethod}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            SavedSignaturePreview(
              serializedPath = contract.signaturePath,
              modifier =
                Modifier.fillMaxWidth()
                  .height(74.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .background(MaterialTheme.colorScheme.surfaceVariant),
            )

            Text(
              text = "Taariikhda: $dateText",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun SavedSignaturePreview(serializedPath: String, modifier: Modifier = Modifier) {
  val strokeColor = MaterialTheme.colorScheme.primary
  Canvas(modifier = modifier) {
    val strokes =
      serializedPath.split("|").mapNotNull { seg ->
        val pts =
          seg.split(";").mapNotNull { pair ->
            val coords = pair.split(",")
            if (coords.size == 2) {
              val x = coords[0].toFloatOrNull()
              val y = coords[1].toFloatOrNull()
              if (x != null && y != null) Offset(x, y) else null
            } else null
          }
        pts.takeIf { it.size >= 2 }
      }
    if (strokes.isEmpty()) return@Canvas
    val allPts = strokes.flatten()
    val minX = allPts.minOf { it.x }
    val maxX = (allPts.maxOf { it.x } - minX).coerceAtLeast(1f)
    val minY = allPts.minOf { it.y }
    val maxY = (allPts.maxOf { it.y } - minY).coerceAtLeast(1f)
    val pad = 12.dp.toPx()
    val availW = (size.width - pad * 2f).coerceAtLeast(1f)
    val availH = (size.height - pad * 2f).coerceAtLeast(1f)

    strokes.forEach { pts ->
      val path = Path()
      pts.forEachIndexed { idx, pt ->
        val nx = pad + ((pt.x - minX) / maxX) * availW
        val ny = pad + ((pt.y - minY) / maxY) * availH
        if (idx == 0) path.moveTo(nx, ny) else path.lineTo(nx, ny)
      }
      drawPath(
        path = path,
        color = strokeColor,
        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
      )
    }
  }
}

@Composable
fun AccountProfileView(
  userName: String,
  userEmail: String,
  bookmarks: List<Bookmark>,
  contractsCount: Int,
  paymentsCount: Int,
  onSignOutClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val extraColors = LocalGuriXalColors.current

  Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
    Card(
      shape = RoundedCornerShape(26.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = BorderStroke(1.dp, extraColors.cardBorder),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(
        modifier = Modifier.padding(22.dp).fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Box(
          modifier =
            Modifier.size(68.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primaryContainer),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Filled.Person,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(34.dp),
          )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = userName.ifBlank { stringResource(R.string.account_title) },
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onSurface,
        )
        if (userEmail.isNotBlank()) {
          Text(
            text = userEmail,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        Spacer(modifier = Modifier.height(18.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          AccountStatPill(
            label = "Kaydsan",
            value = bookmarks.size.toString(),
            modifier = Modifier.weight(1f),
          )
          AccountStatPill(
            label = "Heshiisyo",
            value = contractsCount.toString(),
            modifier = Modifier.weight(1f),
          )
          AccountStatPill(
            label = "Bixinta",
            value = paymentsCount.toString(),
            modifier = Modifier.weight(1f),
          )
        }

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedButton(
          onClick = onSignOutClick,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().height(50.dp).testTag("sign_out_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Logout,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.btn_sign_out),
            style = MaterialTheme.typography.labelLarge,
          )
        }
      }
    }
  }
}

@Composable
private fun AccountStatPill(label: String, value: String, modifier: Modifier = Modifier) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = MaterialTheme.colorScheme.surfaceVariant,
    modifier = modifier,
  ) {
    Column(
      modifier = Modifier.padding(12.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = value,
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.primary,
      )
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}
