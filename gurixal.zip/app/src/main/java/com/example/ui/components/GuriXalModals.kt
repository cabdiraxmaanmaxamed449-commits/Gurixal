package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.PropertyListing
import com.example.ui.FilterConfig
import com.example.ui.theme.LocalGuriXalColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PropertyDetailBottomSheet(
  property: PropertyListing,
  onDismiss: () -> Unit,
  onOpenMobilePayment: () -> Unit,
  onOpenContractSign: () -> Unit,
) {
  val extraColors = LocalGuriXalColors.current
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val priceSuffix = if (property.type == "Rent") "/mo" else ""

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    dragHandle = null,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)
    ) {
      Box(modifier = Modifier.fillMaxWidth().height(230.dp)) {
        PropertyArtworkImage(
          imageUrl = property.imageUrl,
          title = property.title,
          modifier = Modifier.fillMaxSize(),
        )

        IconButton(
          onClick = onDismiss,
          modifier =
            Modifier.align(Alignment.TopEnd)
              .padding(12.dp)
              .size(48.dp)
              .testTag("close_detail_modal_button"),
        ) {
          Box(
            modifier =
              Modifier.size(34.dp)
                .clip(CircleShape)
                .background(extraColors.toastSurface.copy(alpha = 0.7f)),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.Close,
              contentDescription = "Close",
              tint = MaterialTheme.colorScheme.onPrimary,
              modifier = Modifier.size(18.dp),
            )
          }
        }

        Surface(
          shape = CircleShape,
          color = extraColors.headerGradientStart.copy(alpha = 0.92f),
          modifier = Modifier.align(Alignment.BottomStart).padding(12.dp),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Filled.VerifiedUser,
              contentDescription = null,
              tint = extraColors.goldAccent,
              modifier = Modifier.size(15.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = stringResource(R.string.detail_verified_chip),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onPrimary,
            )
          }
        }
      }

      Column(
        modifier = Modifier.padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Top,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = property.title,
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Filled.LocationOn,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(15.dp),
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = property.location,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          Text(
            text = "${formatUsd(property.price)}$priceSuffix",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.primary,
          )
        }

        // Appraiser Report 100% Legal Card
        Surface(
          shape = RoundedCornerShape(18.dp),
          color = MaterialTheme.colorScheme.primaryContainer,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(
                text = stringResource(R.string.appraiser_report_title),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.weight(1f),
              )
              Text(
                text = stringResource(R.string.appraiser_report_legal),
                style = MaterialTheme.typography.labelMedium,
                color = extraColors.verifiedGreen,
              )
            }
            Text(
              text = stringResource(R.string.appraiser_report_desc),
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
            )
          }
        }

        // 3-Column Specs
        Surface(
          shape = RoundedCornerShape(18.dp),
          color = MaterialTheme.colorScheme.surfaceVariant,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier.padding(14.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
          ) {
            DetailSpecColumn(
              label = stringResource(R.string.spec_beds_label),
              value = "${property.beds} Beds",
            )
            DetailSpecColumn(
              label = stringResource(R.string.spec_baths_label),
              value = "${property.baths} Baths",
            )
            DetailSpecColumn(
              label = stringResource(R.string.spec_area_label),
              value = "${property.area} m²",
            )
          }
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Text(
            text = stringResource(R.string.detail_description_heading).uppercase(),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = property.description,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          OutlinedButton(
            onClick = onOpenContractSign,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.height(52.dp).testTag("detail_open_contract_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.Description,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = stringResource(R.string.btn_open_lease),
              style = MaterialTheme.typography.labelLarge,
            )
          }

          Button(
            onClick = onOpenMobilePayment,
            shape = RoundedCornerShape(16.dp),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
              ),
            modifier =
              Modifier.weight(1f).height(52.dp).testTag("detail_mobile_payment_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.AccountBalanceWallet,
              contentDescription = null,
              tint = extraColors.goldAccent,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = stringResource(R.string.btn_mobile_payment),
              style = MaterialTheme.typography.labelLarge,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun DetailSpecColumn(label: String, value: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Text(
      text = value,
      style = MaterialTheme.typography.titleSmall,
      color = MaterialTheme.colorScheme.onSurface,
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MobilePaymentBottomSheet(
  propertyTitle: String,
  amountUsd: Double,
  isProcessing: Boolean,
  onDismiss: () -> Unit,
  onSubmitPayment: (provider: String, phone: String) -> Unit,
) {
  val extraColors = LocalGuriXalColors.current
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var selectedProvider by remember { mutableStateOf("EVC Plus") }
  var phoneInput by remember { mutableStateOf("61 555 1234") }

  val providers =
    listOf(
      Triple("EVC Plus", "Hormuud", "EVC" to extraColors.evcBadge),
      Triple("Premier Wallet", "Premier Bank", "P" to extraColors.premierBadge),
      Triple("SAHAL", "Golis", "S" to extraColors.sahalBadge),
      Triple("Zaad", "Telesom", "Z" to extraColors.zaadBadge),
    )

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Box(
        modifier =
          Modifier.size(48.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.PhoneAndroid,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(24.dp),
        )
      }

      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = stringResource(R.string.payment_modal_title),
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = "$propertyTitle • ${formatUsd(amountUsd)}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.primary,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = stringResource(R.string.payment_modal_subtitle),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      // 2x2 Provider Grid
      Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        providers.chunked(2).forEach { rowItems ->
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            rowItems.forEach { (name, sub, badge) ->
              val active = selectedProvider == name
              Surface(
                onClick = { selectedProvider = name },
                shape = RoundedCornerShape(16.dp),
                color =
                  if (active) MaterialTheme.colorScheme.primaryContainer
                  else MaterialTheme.colorScheme.surface,
                border =
                  BorderStroke(
                    width = if (active) 2.dp else 1.dp,
                    color =
                      if (active) MaterialTheme.colorScheme.primary else extraColors.cardBorder,
                  ),
                modifier =
                  Modifier.weight(1f)
                    .height(60.dp)
                    .testTag("payment_provider_${name.lowercase().replace(" ", "_")}"),
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Box(
                    modifier =
                      Modifier.size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(badge.second),
                    contentAlignment = Alignment.Center,
                  ) {
                    Text(
                      text = badge.first,
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = FontWeight.ExtraBold,
                      color = MaterialTheme.colorScheme.onPrimary,
                    )
                  }
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text(
                      text = name,
                      style = MaterialTheme.typography.labelMedium,
                      color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                      text = sub,
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }
              }
            }
          }
        }
      }

      OutlinedTextField(
        value = phoneInput,
        onValueChange = { phoneInput = it },
        label = { Text(stringResource(R.string.payment_phone_label)) },
        prefix = { Text("+252 ", fontWeight = FontWeight.Bold) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("payment_phone_input"),
      )

      Button(
        onClick = { onSubmitPayment(selectedProvider, phoneInput) },
        enabled = !isProcessing,
        shape = RoundedCornerShape(16.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
        modifier = Modifier.fillMaxWidth().height(54.dp).testTag("submit_mobile_payment_button"),
      ) {
        if (isProcessing) {
          CircularProgressIndicator(
            modifier = Modifier.size(20.dp),
            color = MaterialTheme.colorScheme.onPrimary,
            strokeWidth = 2.dp,
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = stringResource(R.string.payment_sending_ussd),
            style = MaterialTheme.typography.labelLarge,
          )
        } else {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Send,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.payment_submit_btn),
            style = MaterialTheme.typography.labelLarge,
          )
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalContractBottomSheet(
  initialPropertyTitle: String,
  initialMonthlyRent: Double,
  onDismiss: () -> Unit,
  onSaveContract:
    (
      propertyTitle: String,
      paymentMethod: String,
      monthlyRent: Double,
      strokes: List<List<Offset>>,
    ) -> Unit,
) {
  val extraColors = LocalGuriXalColors.current
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  var propertyTitle by remember {
    mutableStateOf(initialPropertyTitle.ifBlank { "Oceanview Apartment 4B" })
  }
  var paymentMethod by remember { mutableStateOf("EVC Plus") }
  val completedStrokes = remember { mutableStateListOf<List<Offset>>() }
  var activeStroke by remember { mutableStateOf<List<Offset>>(emptyList()) }

  val strokeInkColor = MaterialTheme.colorScheme.primary

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp)
          .padding(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.Description,
          contentDescription = null,
          tint = extraColors.goldAccent,
          modifier = Modifier.size(24.dp),
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = stringResource(R.string.contract_title),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = stringResource(R.string.contract_subtitle),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      OutlinedTextField(
        value = propertyTitle,
        onValueChange = { propertyTitle = it },
        label = { Text(stringResource(R.string.add_property_name_label)) },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("contract_property_input"),
      )

      Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, extraColors.cardBorder),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = stringResource(R.string.contract_clause_parties),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = stringResource(R.string.contract_clause_1),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Text(
            text = stringResource(R.string.contract_clause_2),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        listOf("EVC Plus", "Premier Wallet", "SAHAL", "Zaad").forEach { method ->
          FilterChip(
            selected = paymentMethod == method,
            onClick = { paymentMethod = method },
            label = { Text(method, style = MaterialTheme.typography.labelSmall) },
          )
        }
      }

      // E-Signature Canvas Header + Clear
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = stringResource(R.string.contract_sign_label),
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.onSurface,
        )
        TextButton(
          onClick = {
            completedStrokes.clear()
            activeStroke = emptyList()
          },
          modifier = Modifier.testTag("clear_signature_button"),
        ) {
          Text(
            text = stringResource(R.string.contract_clear_btn),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.error,
          )
        }
      }

      Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth().height(140.dp).testTag("signature_canvas_box"),
      ) {
        Canvas(
          modifier =
            Modifier.fillMaxSize().pointerInput(Unit) {
              detectDragGestures(
                onDragStart = { startOffset -> activeStroke = listOf(startOffset) },
                onDrag = { change, _ ->
                  change.consume()
                  activeStroke = activeStroke + change.position
                },
                onDragEnd = {
                  if (activeStroke.size >= 2) {
                    completedStrokes.add(activeStroke)
                  }
                  activeStroke = emptyList()
                },
                onDragCancel = { activeStroke = emptyList() },
              )
            }
        ) {
          val allToDraw =
            if (activeStroke.size >= 2) completedStrokes + listOf(activeStroke)
            else completedStrokes.toList()
          allToDraw.forEach { pts ->
            val path = Path()
            pts.forEachIndexed { idx, pt ->
              if (idx == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
            }
            drawPath(
              path = path,
              color = strokeInkColor,
              style =
                Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
          }
        }
      }

      Button(
        onClick = {
          onSaveContract(
            propertyTitle,
            paymentMethod,
            initialMonthlyRent.takeIf { it > 0.0 } ?: 450.0,
            completedStrokes.toList(),
          )
        },
        shape = RoundedCornerShape(16.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = extraColors.goldAccent,
            contentColor = extraColors.onGoldAccent,
          ),
        modifier = Modifier.fillMaxWidth().height(54.dp).testTag("save_contract_button"),
      ) {
        Text(
          text = stringResource(R.string.contract_save_btn),
          style = MaterialTheme.typography.labelLarge,
        )
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPropertyBottomSheet(
  onDismiss: () -> Unit,
  onPublishProperty:
    (
      title: String,
      type: String,
      category: String,
      district: String,
      price: String,
      beds: String,
      baths: String,
      area: String,
      description: String,
    ) -> Unit,
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var title by remember { mutableStateOf("") }
  var type by remember { mutableStateOf("Rent") }
  var category by remember { mutableStateOf("Apartment") }
  var district by remember { mutableStateOf("Hodan") }
  var price by remember { mutableStateOf("550") }
  var beds by remember { mutableStateOf("3") }
  var baths by remember { mutableStateOf("2") }
  var area by remember { mutableStateOf("145") }
  var description by remember { mutableStateOf("") }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp)
          .padding(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Text(
        text = stringResource(R.string.add_property_title),
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onSurface,
      )

      OutlinedTextField(
        value = title,
        onValueChange = { title = it },
        label = { Text(stringResource(R.string.add_property_name_label)) },
        placeholder = { Text("Luxury Apartment Hodan") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("new_property_title_input"),
      )

      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Rent", "Buy").forEach { item ->
          FilterChip(
            selected = type == item,
            onClick = { type = item },
            label = { Text(if (item == "Rent") "Rent (Kiro)" else "Buy (Iib)") },
          )
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Apartment", "Villa", "Land").forEach { cat ->
          FilterChip(
            selected = category == cat,
            onClick = { category = cat },
            label = { Text(cat) },
          )
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("Hodan", "Wadajir", "Abdiaziz", "Karan").forEach { dist ->
          FilterChip(
            selected = district == dist,
            onClick = { district = dist },
            label = { Text(dist, style = MaterialTheme.typography.labelSmall) },
          )
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
          value = price,
          onValueChange = { price = it.filter { ch -> ch.isDigit() || ch == '.' } },
          label = { Text("Qiimaha ($)") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1f).testTag("new_property_price_input"),
        )
        OutlinedTextField(
          value = area,
          onValueChange = { area = it.filter { ch -> ch.isDigit() } },
          label = { Text("Bedka (m²)") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1f).testTag("new_property_area_input"),
        )
      }

      if (category != "Land") {
        Row(
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          OutlinedTextField(
            value = beds,
            onValueChange = { beds = it.filter { ch -> ch.isDigit() } },
            label = { Text("Qolalka (Beds)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f),
          )
          OutlinedTextField(
            value = baths,
            onValueChange = { baths = it.filter { ch -> ch.isDigit() } },
            label = { Text("Musqusha (Baths)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f),
          )
        }
      }

      OutlinedTextField(
        value = description,
        onValueChange = { description = it },
        label = { Text("Faahfaahinta (Optional)") },
        minLines = 2,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
      )

      Button(
        onClick = {
          onPublishProperty(
            title,
            type,
            category,
            district,
            price,
            beds,
            baths,
            area,
            description,
          )
        },
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().height(52.dp).testTag("publish_property_button"),
      ) {
        Text(
          text = stringResource(R.string.add_property_publish_btn),
          style = MaterialTheme.typography.labelLarge,
        )
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewMaintenanceTicketSheet(
  onDismiss: () -> Unit,
  onSubmitTicket: (title: String, unit: String, desc: String, fundi: String) -> Unit,
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var title by remember { mutableStateOf("") }
  var unit by remember { mutableStateOf("Apt 4B, Abdiaziz") }
  var desc by remember { mutableStateOf("") }
  var fundi by remember { mutableStateOf("Dahir Plumbing Service") }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Text(
        text = "Codsi Dayactir Cusub",
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onSurface,
      )
      OutlinedTextField(
        value = title,
        onValueChange = { title = it },
        label = { Text("Cinwaanka Ciladda") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("ticket_title_input"),
      )
      OutlinedTextField(
        value = unit,
        onValueChange = { unit = it },
        label = { Text("Guriga / Degmada") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
      )
      OutlinedTextField(
        value = fundi,
        onValueChange = { fundi = it },
        label = { Text("Shirkadda Fundiga") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
      )
      OutlinedTextField(
        value = desc,
        onValueChange = { desc = it },
        label = { Text("Faahfaahinta Dayactirka") },
        minLines = 2,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("ticket_desc_input"),
      )
      Button(
        onClick = { onSubmitTicket(title, unit, desc, fundi) },
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().height(52.dp).testTag("submit_ticket_button"),
      ) {
        Text("Gudbi Dayactirka", style = MaterialTheme.typography.labelLarge)
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PropertyFilterBottomSheet(
  currentFilters: FilterConfig,
  onDismiss: () -> Unit,
  onApply: (category: String, bookmarksOnly: Boolean) -> Unit,
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var selectedCategory by remember { mutableStateOf(currentFilters.selectedCategory) }
  var bookmarksOnly by remember { mutableStateOf(currentFilters.bookmarksOnly) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Text(
        text = stringResource(R.string.filter_modal_title),
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onSurface,
      )

      Text(
        text = stringResource(R.string.filter_category_label),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )

      Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        listOf("All" to "Dhammaan", "Apartment" to "Apartment", "Villa" to "Villa", "Land" to "Land")
          .forEach { (key, label) ->
            FilterChip(
              selected = selectedCategory == key,
              onClick = { selectedCategory = key },
              label = { Text(label) },
              modifier = Modifier.testTag("filter_cat_${key.lowercase()}"),
            )
          }
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Checkbox(
          checked = bookmarksOnly,
          onCheckedChange = { bookmarksOnly = it },
          modifier = Modifier.testTag("filter_bookmarks_checkbox"),
        )
        Text(
          text = stringResource(R.string.filter_bookmarks_only),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }

      Button(
        onClick = { onApply(selectedCategory, bookmarksOnly) },
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().height(52.dp).testTag("apply_filters_button"),
      ) {
        Text(
          text = stringResource(R.string.filter_apply_btn),
          style = MaterialTheme.typography.labelLarge,
        )
      }
    }
  }
}
