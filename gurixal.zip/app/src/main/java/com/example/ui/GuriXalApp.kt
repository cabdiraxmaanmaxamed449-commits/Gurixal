package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PieChart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.auth.authStateFlow
import com.example.auth.signOut
import com.example.data.GuriXalRepository
import com.example.data.PropertyListing
import com.example.data.UiState
import com.example.ui.auth.AuthScreen
import com.example.ui.components.AccountProfileView
import com.example.ui.components.AddPropertyBottomSheet
import com.example.ui.components.DigitalContractBottomSheet
import com.example.ui.components.DigitalContractsHubView
import com.example.ui.components.DistrictFilterBar
import com.example.ui.components.FloatingToastOverlay
import com.example.ui.components.GuriXalTopHeader
import com.example.ui.components.ManageDashboardContent
import com.example.ui.components.MobilePaymentBottomSheet
import com.example.ui.components.MurabahaMortgageCalculatorCard
import com.example.ui.components.NewMaintenanceTicketSheet
import com.example.ui.components.PillarTabsRow
import com.example.ui.components.PropertyDetailBottomSheet
import com.example.ui.components.PropertyFilterBottomSheet
import com.example.ui.components.PropertyListingCard
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
  val currentUser by
    auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
  val user = currentUser

  if (user == null) {
    AuthScreen()
  } else {
    val viewModel: GuriXalViewModel =
      viewModel(
        key = user.uid,
        factory =
          viewModelFactory {
            initializer {
              val app =
                checkNotNull(this[APPLICATION_KEY]) {
                  "APPLICATION_KEY missing from CreationExtras"
                }
              val databaseId = app.getString(R.string.firestore_database_id)
              val db = FirebaseFirestore.getInstance(databaseId)
              GuriXalRepository(db, auth).let { repo ->
                GuriXalViewModel(
                  repository = repo,
                  currentUserId = user.uid,
                  currentUserName = user.displayName ?: "GuriXal Member",
                  currentUserEmail = user.email.orEmpty(),
                )
              }
            }
          },
      )

    GuriXalMainScreen(viewModel = viewModel)
  }
}

@Composable
fun GuriXalMainScreen(viewModel: GuriXalViewModel) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val credentialManager = remember(context) { CredentialManager.create(context) }

  val bottomDest by viewModel.bottomDestination.collectAsStateWithLifecycle()
  val pillarTab by viewModel.pillarTab.collectAsStateWithLifecycle()
  val filters by viewModel.filters.collectAsStateWithLifecycle()
  val mortgage by viewModel.mortgage.collectAsStateWithLifecycle()
  val selectedProperty by viewModel.selectedProperty.collectAsStateWithLifecycle()
  val showPaymentModal by viewModel.showPaymentModal.collectAsStateWithLifecycle()
  val showContractModal by viewModel.showContractModal.collectAsStateWithLifecycle()
  val showAddPropertyModal by viewModel.showAddPropertyModal.collectAsStateWithLifecycle()
  val showNewTicketModal by viewModel.showNewTicketModal.collectAsStateWithLifecycle()
  val showFilterModal by viewModel.showFilterModal.collectAsStateWithLifecycle()
  val isProcessingPayment by viewModel.isProcessingPayment.collectAsStateWithLifecycle()
  val toastBanner by viewModel.toastBanner.collectAsStateWithLifecycle()

  val propertiesState by viewModel.propertiesState.collectAsStateWithLifecycle()
  val bookmarksState by viewModel.bookmarksState.collectAsStateWithLifecycle()
  val contractsState by viewModel.contractsState.collectAsStateWithLifecycle()
  val paymentsState by viewModel.paymentsState.collectAsStateWithLifecycle()
  val ticketsState by viewModel.ticketsState.collectAsStateWithLifecycle()

  // Handle back button on secondary destinations or sub-tabs
  BackHandler(
    enabled = bottomDest != BottomNavDestination.EXPLORE || pillarTab != PillarTab.FIND
  ) {
    viewModel.navigateBackToExplore()
  }

  val bookmarkedIds by
    remember(bookmarksState) {
      derivedStateOf {
        (bookmarksState as? UiState.Success)?.data?.map { it.propertyId }?.toSet() ?: emptySet()
      }
    }

  val allProperties = (propertiesState as? UiState.Success)?.data ?: emptyList()
  val allBookmarks = (bookmarksState as? UiState.Success)?.data ?: emptyList()
  val allContracts = (contractsState as? UiState.Success)?.data ?: emptyList()
  val allPayments = (paymentsState as? UiState.Success)?.data ?: emptyList()
  val allTickets = (ticketsState as? UiState.Success)?.data ?: emptyList()

  val filteredProperties by
    remember(allProperties, pillarTab, filters, bookmarkedIds) {
      derivedStateOf {
        allProperties.filter { p ->
          val matchesPillar =
            when (pillarTab) {
              PillarTab.BUY -> p.type == "Buy"
              PillarTab.RENT -> p.type == "Rent"
              else -> true
            }
          val matchesDistrict =
            filters.selectedDistrict == "all" ||
              p.district.equals(filters.selectedDistrict, ignoreCase = true)
          val matchesCategory =
            filters.selectedCategory == "All" ||
              p.category.equals(filters.selectedCategory, ignoreCase = true)
          val matchesBookmarks = !filters.bookmarksOnly || bookmarkedIds.contains(p.id)
          val q = filters.searchQuery.trim()
          val matchesSearch =
            q.isEmpty() ||
              p.title.contains(q, ignoreCase = true) ||
              p.location.contains(q, ignoreCase = true) ||
              p.district.contains(q, ignoreCase = true) ||
              p.category.contains(q, ignoreCase = true)

          matchesPillar &&
            matchesDistrict &&
            matchesCategory &&
            matchesBookmarks &&
            matchesSearch
        }
      }
    }

  val userInitials =
    remember(viewModel.currentUserName) {
      viewModel.currentUserName
        .split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercaseChar().toString() }
        .ifBlank { "GX" }
    }

  val notifTitle = stringResource(R.string.toast_notifications_title)
  val notifEmpty = stringResource(R.string.toast_notifications_empty)

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val isExpandedScreen = maxWidth >= 600.dp

    Row(modifier = Modifier.fillMaxSize()) {
      if (isExpandedScreen) {
        GuriXalNavRail(
          currentDestination = bottomDest,
          onSelect = viewModel::selectBottomDestination,
        )
      }

      Scaffold(
        modifier = Modifier.weight(1f),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
          GuriXalTopHeader(
            userInitials = userInitials,
            searchQuery = filters.searchQuery,
            onSearchChange = viewModel::updateSearchQuery,
            onOpenFilter = viewModel::openFilterModal,
            onNotificationClick = { viewModel.showToast(notifTitle, notifEmpty) },
            onProfileClick = {
              viewModel.selectBottomDestination(BottomNavDestination.ACCOUNT)
            },
            showSearchBar = bottomDest == BottomNavDestination.EXPLORE,
          )
        },
        bottomBar = {
          if (!isExpandedScreen) {
            GuriXalBottomNavBar(
              currentDestination = bottomDest,
              onSelect = viewModel::selectBottomDestination,
            )
          }
        },
        containerColor = MaterialTheme.colorScheme.background,
      ) { innerPadding ->
        Box(
          modifier = Modifier.fillMaxSize().padding(innerPadding),
          contentAlignment = Alignment.TopCenter,
        ) {
          LazyColumn(
            modifier = Modifier.fillMaxSize().widthIn(max = 760.dp),
            contentPadding =
              PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            when (bottomDest) {
              BottomNavDestination.EXPLORE -> {
                item {
                  PillarTabsRow(
                    selectedTab = pillarTab,
                    onSelectTab = viewModel::selectPillarTab,
                  )
                }

                item {
                  DistrictFilterBar(
                    selectedDistrict = filters.selectedDistrict,
                    onSelectDistrict = viewModel::selectDistrict,
                  )
                }

                if (pillarTab == PillarTab.BUY) {
                  item {
                    MurabahaMortgageCalculatorCard(
                      state = mortgage,
                      onPriceChange = viewModel::updateMortgagePrice,
                      onDownChange = viewModel::updateMortgageDown,
                      onYearsChange = viewModel::updateMortgageYears,
                      onPrequalifyClick = {
                        viewModel.showToast(
                          "Codsiga Amaahda",
                          "Nidaamka Murabaxada ee Bangiga wuu furan yahay — codsigaaga waa la diiwaangeliyay.",
                        )
                      },
                    )
                  }
                }

                item {
                  ListingsSectionHeader(
                    pillarTab = pillarTab,
                    count = filteredProperties.size,
                  )
                }

                when (val pState = propertiesState) {
                  is UiState.Loading -> {
                    item {
                      Box(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 36.dp),
                        contentAlignment = Alignment.Center,
                      ) {
                        CircularProgressIndicator()
                      }
                    }
                  }
                  is UiState.Error -> {
                    item {
                      EmptyOrErrorCard(title = "Cilad Xogta", subtitle = pState.message)
                    }
                  }
                  is UiState.Success -> {
                    if (filteredProperties.isEmpty()) {
                      item {
                        EmptyOrErrorCard(
                          title = stringResource(R.string.empty_properties_title),
                          subtitle = stringResource(R.string.empty_properties_subtitle),
                        )
                      }
                    } else {
                      items(filteredProperties, key = { it.id }) { prop ->
                        val bookmarked = bookmarkedIds.contains(prop.id)
                        PropertyListingCard(
                          property = prop,
                          isBookmarked = bookmarked,
                          onCardClick = { viewModel.openPropertyDetail(prop) },
                          onToggleBookmark = { viewModel.toggleBookmark(prop, bookmarked) },
                        )
                      }
                    }
                  }
                }
              }

              BottomNavDestination.DASHBOARD -> {
                item {
                  PillarTabsRow(
                    selectedTab = PillarTab.MANAGE,
                    onSelectTab = viewModel::selectPillarTab,
                  )
                }
                item {
                  ManageDashboardContent(
                    properties = allProperties,
                    payments = allPayments,
                    tickets = allTickets,
                    onOpenAddProperty = viewModel::openAddPropertyModal,
                    onOpenNewTicket = viewModel::openNewTicketModal,
                    onCallFundi = { ticket ->
                      viewModel.showToast(
                        "Fundi Direct",
                        "Farsamoyaqaan (${ticket.fundiName}) ayaa lala xiriiray.",
                      )
                    },
                    onAdvanceTicketStatus = viewModel::advanceMaintenanceStatus,
                  )
                }
              }

              BottomNavDestination.CONTRACT -> {
                item {
                  DigitalContractsHubView(
                    contracts = allContracts,
                    onOpenSignContractModal = viewModel::openContractModal,
                  )
                }
              }

              BottomNavDestination.ACCOUNT -> {
                item {
                  AccountProfileView(
                    userName = viewModel.currentUserName,
                    userEmail = viewModel.currentUserEmail,
                    bookmarks = allBookmarks,
                    contractsCount = allContracts.size,
                    paymentsCount = allPayments.size,
                    onSignOutClick = {
                      signOut(
                        credentialManager = credentialManager,
                        onSignOutComplete = {},
                        scope = scope,
                      )
                    },
                  )
                }
              }
            }
          }
        }
      }
    }

    // Floating Toast Notification Banner
    FloatingToastOverlay(
      toast = toastBanner,
      modifier = Modifier.align(Alignment.TopCenter),
    )
  }

  // --- Interactive Modals ---

  val activeProperty: PropertyListing? = selectedProperty
  if (activeProperty != null && !showPaymentModal && !showContractModal) {
    PropertyDetailBottomSheet(
      property = activeProperty,
      onDismiss = viewModel::closePropertyDetail,
      onOpenMobilePayment = viewModel::openPaymentSheetForSelected,
      onOpenContractSign = viewModel::openContractModal,
    )
  }

  if (showPaymentModal) {
    MobilePaymentBottomSheet(
      propertyTitle = activeProperty?.title ?: "GuriXal Verified Unit",
      amountUsd = activeProperty?.price ?: 600.0,
      isProcessing = isProcessingPayment,
      onDismiss = viewModel::closePaymentModal,
      onSubmitPayment = viewModel::submitMobilePayment,
    )
  }

  if (showContractModal) {
    DigitalContractBottomSheet(
      initialPropertyTitle = activeProperty?.title.orEmpty(),
      initialMonthlyRent =
        activeProperty?.takeIf { it.type == "Rent" }?.price ?: 450.0,
      onDismiss = viewModel::closeContractModal,
      onSaveContract = viewModel::signAndSaveContract,
    )
  }

  if (showAddPropertyModal) {
    AddPropertyBottomSheet(
      onDismiss = viewModel::closeAddPropertyModal,
      onPublishProperty = viewModel::publishNewProperty,
    )
  }

  if (showNewTicketModal) {
    NewMaintenanceTicketSheet(
      onDismiss = viewModel::closeNewTicketModal,
      onSubmitTicket = viewModel::submitMaintenanceTicket,
    )
  }

  if (showFilterModal) {
    PropertyFilterBottomSheet(
      currentFilters = filters,
      onDismiss = viewModel::closeFilterModal,
      onApply = viewModel::applyFilters,
    )
  }
}

@Composable
private fun ListingsSectionHeader(pillarTab: PillarTab, count: Int) {
  val titleRes =
    when (pillarTab) {
      PillarTab.BUY -> R.string.section_buy_properties
      PillarTab.RENT -> R.string.section_rent_properties
      else -> R.string.section_verified_properties
    }
  Row(
    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = stringResource(titleRes).uppercase(),
      style = MaterialTheme.typography.labelMedium,
      fontWeight = FontWeight.ExtraBold,
      color = MaterialTheme.colorScheme.onBackground,
    )
    Surface(
      shape = RoundedCornerShape(8.dp),
      color = MaterialTheme.colorScheme.primaryContainer,
    ) {
      Text(
        text = stringResource(R.string.properties_count_format, count),
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onPrimaryContainer,
        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
      )
    }
  }
}

@Composable
private fun EmptyOrErrorCard(title: String, subtitle: String) {
  Card(
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier.padding(32.dp).fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Icon(
        imageVector = Icons.Filled.Apartment,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(40.dp),
      )
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center,
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
      )
    }
  }
}

@Composable
private fun GuriXalBottomNavBar(
  currentDestination: BottomNavDestination,
  onSelect: (BottomNavDestination) -> Unit,
) {
  NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 4.dp) {
    NavigationBarItem(
      selected = currentDestination == BottomNavDestination.EXPLORE,
      onClick = { onSelect(BottomNavDestination.EXPLORE) },
      icon = {
        Icon(
          imageVector =
            if (currentDestination == BottomNavDestination.EXPLORE) Icons.Filled.Explore
            else Icons.Outlined.Explore,
          contentDescription = stringResource(R.string.nav_explore),
        )
      },
      label = { Text(stringResource(R.string.nav_explore)) },
      modifier = Modifier.testTag("bottom_nav_explore"),
    )
    NavigationBarItem(
      selected = currentDestination == BottomNavDestination.CONTRACT,
      onClick = { onSelect(BottomNavDestination.CONTRACT) },
      icon = {
        Icon(
          imageVector =
            if (currentDestination == BottomNavDestination.CONTRACT) Icons.Filled.Description
            else Icons.Outlined.Description,
          contentDescription = stringResource(R.string.nav_contract),
        )
      },
      label = { Text(stringResource(R.string.nav_contract)) },
      modifier = Modifier.testTag("bottom_nav_contract"),
    )
    NavigationBarItem(
      selected = currentDestination == BottomNavDestination.DASHBOARD,
      onClick = { onSelect(BottomNavDestination.DASHBOARD) },
      icon = {
        Icon(
          imageVector =
            if (currentDestination == BottomNavDestination.DASHBOARD) Icons.Filled.PieChart
            else Icons.Outlined.PieChart,
          contentDescription = stringResource(R.string.nav_dashboard),
        )
      },
      label = { Text(stringResource(R.string.nav_dashboard)) },
      modifier = Modifier.testTag("bottom_nav_dashboard"),
    )
    NavigationBarItem(
      selected = currentDestination == BottomNavDestination.ACCOUNT,
      onClick = { onSelect(BottomNavDestination.ACCOUNT) },
      icon = {
        Icon(
          imageVector =
            if (currentDestination == BottomNavDestination.ACCOUNT) Icons.Filled.Person
            else Icons.Outlined.Person,
          contentDescription = stringResource(R.string.nav_account),
        )
      },
      label = { Text(stringResource(R.string.nav_account)) },
      modifier = Modifier.testTag("bottom_nav_account"),
    )
  }
}

@Composable
private fun GuriXalNavRail(
  currentDestination: BottomNavDestination,
  onSelect: (BottomNavDestination) -> Unit,
) {
  NavigationRail(containerColor = MaterialTheme.colorScheme.surface) {
    Spacer(modifier = Modifier.height(16.dp))
    NavigationRailItem(
      selected = currentDestination == BottomNavDestination.EXPLORE,
      onClick = { onSelect(BottomNavDestination.EXPLORE) },
      icon = { Icon(Icons.Filled.Explore, contentDescription = null) },
      label = { Text(stringResource(R.string.nav_explore)) },
    )
    NavigationRailItem(
      selected = currentDestination == BottomNavDestination.CONTRACT,
      onClick = { onSelect(BottomNavDestination.CONTRACT) },
      icon = { Icon(Icons.Filled.Description, contentDescription = null) },
      label = { Text(stringResource(R.string.nav_contract)) },
    )
    NavigationRailItem(
      selected = currentDestination == BottomNavDestination.DASHBOARD,
      onClick = { onSelect(BottomNavDestination.DASHBOARD) },
      icon = { Icon(Icons.Filled.PieChart, contentDescription = null) },
      label = { Text(stringResource(R.string.nav_dashboard)) },
    )
    NavigationRailItem(
      selected = currentDestination == BottomNavDestination.ACCOUNT,
      onClick = { onSelect(BottomNavDestination.ACCOUNT) },
      icon = { Icon(Icons.Filled.Person, contentDescription = null) },
      label = { Text(stringResource(R.string.nav_account)) },
    )
  }
}
