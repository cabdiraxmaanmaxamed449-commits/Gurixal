package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// GuriXal Core Brand Palette (Dark Teal & Royal Gold)
val Teal950 = Color(0xFF00241F)
val Teal900 = Color(0xFF00332C)
val Teal800 = Color(0xFF004D40) // Primary Dark Teal
val Teal700 = Color(0xFF00695C)
val Teal600 = Color(0xFF00897B) // Emerald Green
val Teal500 = Color(0xFF26A69A)
val Teal100 = Color(0xFFB2DFDB)
val Teal50 = Color(0xFFE0F2F1)

val Gold700 = Color(0xFF8C6F1B)
val Gold600 = Color(0xFFB8972E)
val Gold500 = Color(0xFFD4AF37) // Accent Gold
val Gold400 = Color(0xFFE5C158)
val Gold100 = Color(0xFFFDF8E7)

// Neutral & Architectural Surfaces
val BrandBgLight = Color(0xFFF4F6F8)
val SurfaceWhite = Color(0xFFFFFFFF)
val Slate950 = Color(0xFF020617)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

// Semantic Provider & Status Accents
val EvcEmerald = Color(0xFF059669)
val EvcEmeraldBg = Color(0xFFECFDF5)
val PremierBlue = Color(0xFF1D4ED8)
val SahalPurple = Color(0xFF7E22CE)
val ZaadOrange = Color(0xFFEA580C)
val WarningAmber = Color(0xFFD97706)
val WarningAmberBg = Color(0xFFFEF3C7)
val DangerRed = Color(0xFFDC2626)
