package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.PillarTab
import com.example.ui.ToastBanner
import com.example.ui.theme.LocalGuriXalColors

@Composable
fun GuriXalTopHeader(
  userInitials: String,
  searchQuery: String,
  onSearchChange: (String) -> Unit,
  onOpenFilter: () -> Unit,
  onNotificationClick: () -> Unit,
  onProfileClick: () -> Unit,
  showSearchBar: Boolean = true,
) {
  val extraColors = LocalGuriXalColors.current
  val headerBrush =
    Brush.horizontalGradient(
      colors = listOf(extraColors.headerGradientStart, extraColors.headerGradientEnd)
    )

  Surface(
    modifier = Modifier.fillMaxWidth(),
    shadowElevation = 6.dp,
    color = extraColors.headerGradientStart,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .background(headerBrush)
          .windowInsetsPadding(WindowInsets.statusBars)
          .padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        // Brand Logo & Tagline
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp,
            modifier = Modifier.size(44.dp).testTag("header_gurixal_logo"),
          ) {
            androidx.compose.foundation.Image(
              painter = androidx.compose.ui.res.painterResource(id = R.drawable.ic_gurixal_emblem),
              contentDescription = stringResource(R.string.app_name),
              modifier = Modifier.padding(4.dp),
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text =
                buildAnnotatedString {
                  append(stringResource(R.string.brand_prefix))
                  withStyle(SpanStyle(color = extraColors.goldAccent)) {
                    append(stringResource(R.string.brand_suffix))
                  }
                },
              style = MaterialTheme.typography.headlineSmall,
              color = MaterialTheme.colorScheme.onPrimary,
            )
            Text(
              text = stringResource(R.string.brand_tagline).uppercase(),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.78f),
            )
          }
        }

        // Notification Bell & Profile Initials Badge
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Box {
            IconButton(
              onClick = onNotificationClick,
              modifier =
                Modifier.size(48.dp)
                  .clip(RoundedCornerShape(14.dp))
                  .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.12f))
                  .testTag("notifications_button"),
            ) {
              Icon(
                imageVector = Icons.Filled.Notifications,
                contentDescription = stringResource(R.string.cd_notifications),
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(20.dp),
              )
            }
            Box(
              modifier =
                Modifier.align(Alignment.TopEnd)
                  .padding(top = 10.dp, end = 10.dp)
                  .size(8.dp)
                  .clip(CircleShape)
                  .background(extraColors.goldAccent)
            )
          }

          Surface(
            onClick = onProfileClick,
            shape = RoundedCornerShape(14.dp),
            color = extraColors.goldAccent,
            modifier = Modifier.size(48.dp).testTag("header_profile_button"),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Text(
                text = userInitials,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.ExtraBold,
                color = extraColors.onGoldAccent,
              )
            }
          }
        }
      }

      if (showSearchBar) {
        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Surface(
            modifier = Modifier.weight(1f).height(48.dp),
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                if (searchQuery.isEmpty()) {
                  Text(
                    text = stringResource(R.string.search_placeholder),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
                BasicTextField(
                  value = searchQuery,
                  onValueChange = onSearchChange,
                  singleLine = true,
                  textStyle =
                    MaterialTheme.typography.bodySmall.copy(
                      color = MaterialTheme.colorScheme.onSurface,
                      fontWeight = FontWeight.Medium,
                    ),
                  cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                  modifier = Modifier.fillMaxWidth().testTag("property_search_input"),
                )
              }
              if (searchQuery.isNotEmpty()) {
                IconButton(
                  onClick = { onSearchChange("") },
                  modifier = Modifier.size(36.dp).testTag("clear_search_button"),
                ) {
                  Icon(
                    imageVector = Icons.Filled.Clear,
                    contentDescription = stringResource(R.string.cd_clear_search),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp),
                  )
                }
              }
            }
          }

          Surface(
            onClick = onOpenFilter,
            shape = RoundedCornerShape(14.dp),
            color = extraColors.goldAccent,
            modifier = Modifier.size(48.dp).testTag("open_filters_button"),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Filled.Tune,
                contentDescription = stringResource(R.string.cd_open_filters),
                tint = extraColors.onGoldAccent,
                modifier = Modifier.size(20.dp),
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun PillarTabsRow(
  selectedTab: PillarTab,
  onSelectTab: (PillarTab) -> Unit,
  modifier: Modifier = Modifier,
) {
  val extraColors = LocalGuriXalColors.current

  Row(
    modifier = modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    PillarTabCard(
      label = stringResource(R.string.tab_find),
      icon = Icons.Filled.Search,
      selected = selectedTab == PillarTab.FIND,
      iconBg = MaterialTheme.colorScheme.primaryContainer,
      iconTint = MaterialTheme.colorScheme.primary,
      onClick = { onSelectTab(PillarTab.FIND) },
      testTag = "pillar_tab_find",
      modifier = Modifier.weight(1f),
    )
    PillarTabCard(
      label = stringResource(R.string.tab_buy),
      icon = Icons.Filled.Key,
      selected = selectedTab == PillarTab.BUY,
      iconBg = extraColors.goldContainer,
      iconTint = MaterialTheme.colorScheme.secondary,
      onClick = { onSelectTab(PillarTab.BUY) },
      testTag = "pillar_tab_buy",
      modifier = Modifier.weight(1f),
    )
    PillarTabCard(
      label = stringResource(R.string.tab_rent),
      icon = Icons.Filled.Handshake,
      selected = selectedTab == PillarTab.RENT,
      iconBg = extraColors.verifiedGreenContainer,
      iconTint = extraColors.verifiedGreen,
      onClick = { onSelectTab(PillarTab.RENT) },
      testTag = "pillar_tab_rent",
      modifier = Modifier.weight(1f),
    )
    PillarTabCard(
      label = stringResource(R.string.tab_manage),
      icon = Icons.Filled.PieChart,
      selected = selectedTab == PillarTab.MANAGE,
      iconBg = MaterialTheme.colorScheme.surfaceVariant,
      iconTint = MaterialTheme.colorScheme.onSurfaceVariant,
      onClick = { onSelectTab(PillarTab.MANAGE) },
      testTag = "pillar_tab_manage",
      modifier = Modifier.weight(1f),
    )
  }
}

@Composable
private fun PillarTabCard(
  label: String,
  icon: ImageVector,
  selected: Boolean,
  iconBg: androidx.compose.ui.graphics.Color,
  iconTint: androidx.compose.ui.graphics.Color,
  onClick: () -> Unit,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  val extraColors = LocalGuriXalColors.current
  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(18.dp),
    color = MaterialTheme.colorScheme.surface,
    border =
      BorderStroke(
        width = if (selected) 2.dp else 1.dp,
        color = if (selected) MaterialTheme.colorScheme.primary else extraColors.cardBorder,
      ),
    shadowElevation = if (selected) 3.dp else 0.dp,
    modifier = modifier.minimumInteractiveComponentSize().testTag(testTag),
  ) {
    Column(
      modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Box(
        modifier = Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(iconBg),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = iconTint,
          modifier = Modifier.size(18.dp),
        )
      }
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.ExtraBold,
        color =
          if (selected) MaterialTheme.colorScheme.primary
          else MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
      )
    }
  }
}

@Composable
fun DistrictFilterBar(
  selectedDistrict: String,
  onSelectDistrict: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val districts =
    listOf(
      "all" to stringResource(R.string.district_all),
      "Hodan" to stringResource(R.string.district_hodan),
      "Wadajir" to stringResource(R.string.district_wadajir),
      "Abdiaziz" to stringResource(R.string.district_abdiaziz),
      "Karan" to stringResource(R.string.district_karan),
    )
  val extraColors = LocalGuriXalColors.current

  Row(
    modifier = modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    districts.forEach { (key, label) ->
      val active = selectedDistrict == key
      Surface(
        shape = CircleShape,
        color =
          if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
        border = if (active) null else BorderStroke(1.dp, extraColors.cardBorder),
        modifier =
          Modifier.minimumInteractiveComponentSize()
            .clip(CircleShape)
            .clickable { onSelectDistrict(key) }
            .testTag("district_chip_${key.lowercase()}"),
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
        ) {
          Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color =
              if (active) MaterialTheme.colorScheme.onPrimary
              else MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    }
  }
}

@Composable
fun FloatingToastOverlay(toast: ToastBanner?, modifier: Modifier = Modifier) {
  val extraColors = LocalGuriXalColors.current
  AnimatedVisibility(
    visible = toast != null,
    enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
    exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
    modifier = modifier,
  ) {
    toast?.let { current ->
      Surface(
        shape = RoundedCornerShape(18.dp),
        color = extraColors.toastSurface,
        shadowElevation = 12.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.4f)),
        modifier =
          Modifier.windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .widthIn(max = 420.dp)
            .fillMaxWidth(),
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Box(
            modifier =
              Modifier.size(36.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.CheckCircle,
              contentDescription = null,
              tint = extraColors.goldAccent,
              modifier = Modifier.size(20.dp),
            )
          }
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = current.title,
              style = MaterialTheme.typography.titleSmall,
              color = extraColors.toastText,
            )
            Text(
              text = current.message,
              style = MaterialTheme.typography.bodySmall,
              color = extraColors.toastText.copy(alpha = 0.8f),
            )
          }
        }
      }
    }
  }
}
