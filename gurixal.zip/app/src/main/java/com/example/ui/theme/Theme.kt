package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class GuriXalExtendedColors(
  val goldAccent: Color,
  val goldContainer: Color,
  val onGoldAccent: Color,
  val headerGradientStart: Color,
  val headerGradientEnd: Color,
  val cardBorder: Color,
  val verifiedGreen: Color,
  val verifiedGreenContainer: Color,
  val warningAmber: Color,
  val warningAmberContainer: Color,
  val evcBadge: Color,
  val premierBadge: Color,
  val sahalBadge: Color,
  val zaadBadge: Color,
  val toastSurface: Color,
  val toastText: Color,
)

val LocalGuriXalColors = staticCompositionLocalOf {
  GuriXalExtendedColors(
    goldAccent = Gold500,
    goldContainer = Gold100,
    onGoldAccent = Teal950,
    headerGradientStart = Teal900,
    headerGradientEnd = Teal700,
    cardBorder = Slate200,
    verifiedGreen = EvcEmerald,
    verifiedGreenContainer = EvcEmeraldBg,
    warningAmber = WarningAmber,
    warningAmberContainer = WarningAmberBg,
    evcBadge = EvcEmerald,
    premierBadge = PremierBlue,
    sahalBadge = SahalPurple,
    zaadBadge = ZaadOrange,
    toastSurface = Slate900,
    toastText = SurfaceWhite,
  )
}

private val LightColorScheme =
  lightColorScheme(
    primary = Teal800,
    onPrimary = SurfaceWhite,
    primaryContainer = Teal50,
    onPrimaryContainer = Teal900,
    secondary = Gold600,
    onSecondary = SurfaceWhite,
    secondaryContainer = Gold100,
    onSecondaryContainer = Teal950,
    tertiary = Teal600,
    onTertiary = SurfaceWhite,
    tertiaryContainer = EvcEmeraldBg,
    onTertiaryContainer = Teal900,
    background = BrandBgLight,
    onBackground = Slate900,
    surface = SurfaceWhite,
    onSurface = Slate900,
    surfaceVariant = Slate100,
    onSurfaceVariant = Slate600,
    outline = Slate200,
    outlineVariant = Slate200,
    error = DangerRed,
    onError = SurfaceWhite,
  )

private val DarkColorScheme =
  darkColorScheme(
    primary = Teal500,
    onPrimary = Teal950,
    primaryContainer = Teal800,
    onPrimaryContainer = Teal50,
    secondary = Gold500,
    onSecondary = Teal950,
    secondaryContainer = Teal900,
    onSecondaryContainer = Gold400,
    tertiary = Teal500,
    onTertiary = Teal950,
    tertiaryContainer = Teal900,
    onTertiaryContainer = Teal100,
    background = Slate950,
    onBackground = Slate50,
    surface = Slate900,
    onSurface = Slate50,
    surfaceVariant = Slate800,
    onSurfaceVariant = Slate400,
    outline = Slate800,
    outlineVariant = Slate800,
    error = DangerRed,
    onError = SurfaceWhite,
  )

val GuriXalShapes =
  Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp),
  )

@Composable
fun GuriXalTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  val extendedColors =
    if (darkTheme) {
      GuriXalExtendedColors(
        goldAccent = Gold500,
        goldContainer = Teal900,
        onGoldAccent = Teal950,
        headerGradientStart = Teal950,
        headerGradientEnd = Teal800,
        cardBorder = Slate800,
        verifiedGreen = Teal500,
        verifiedGreenContainer = Teal900,
        warningAmber = Gold400,
        warningAmberContainer = Slate800,
        evcBadge = EvcEmerald,
        premierBadge = PremierBlue,
        sahalBadge = SahalPurple,
        zaadBadge = ZaadOrange,
        toastSurface = Slate800,
        toastText = SurfaceWhite,
      )
    } else {
      GuriXalExtendedColors(
        goldAccent = Gold500,
        goldContainer = Gold100,
        onGoldAccent = Teal950,
        headerGradientStart = Teal900,
        headerGradientEnd = Teal700,
        cardBorder = Slate200,
        verifiedGreen = EvcEmerald,
        verifiedGreenContainer = EvcEmeraldBg,
        warningAmber = WarningAmber,
        warningAmberContainer = WarningAmberBg,
        evcBadge = EvcEmerald,
        premierBadge = PremierBlue,
        sahalBadge = SahalPurple,
        zaadBadge = ZaadOrange,
        toastSurface = Slate900,
        toastText = SurfaceWhite,
      )
    }

  CompositionLocalProvider(LocalGuriXalColors provides extendedColors) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = Typography,
      shapes = GuriXalShapes,
      content = content,
    )
  }
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  GuriXalTheme(darkTheme = darkTheme, content = content)
}
