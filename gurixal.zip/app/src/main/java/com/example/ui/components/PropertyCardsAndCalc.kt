package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bathtub
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.SquareFoot
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import com.example.R
import com.example.data.PropertyListing
import com.example.ui.MortgageState
import com.example.ui.theme.LocalGuriXalColors
import java.text.NumberFormat
import java.util.Locale

fun formatUsd(amount: Double, decimals: Int = 0): String {
  val nf = NumberFormat.getNumberInstance(Locale.US)
  nf.minimumFractionDigits = decimals
  nf.maximumFractionDigits = decimals
  return "$${nf.format(amount)}"
}

@Composable
fun PropertyListingCard(
  property: PropertyListing,
  isBookmarked: Boolean,
  onCardClick: () -> Unit,
  onToggleBookmark: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val extraColors = LocalGuriXalColors.current
  val priceSuffix = if (property.type == "Rent") "/mo" else ""

  Card(
    onClick = onCardClick,
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, extraColors.cardBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier.fillMaxWidth().testTag("property_card_${property.id}"),
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      Box(modifier = Modifier.fillMaxWidth().height(190.dp)) {
        PropertyArtworkImage(
          imageUrl = property.imageUrl,
          title = property.title,
          modifier = Modifier.fillMaxSize(),
        )

        // Top-left Rent / Buy badge
        Surface(
          shape = CircleShape,
          color = extraColors.headerGradientStart.copy(alpha = 0.9f),
          modifier = Modifier.align(Alignment.TopStart).padding(12.dp),
        ) {
          Text(
            text = property.type.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
          )
        }

        // Top-right Bookmark Heart (48dp touch target)
        IconButton(
          onClick = onToggleBookmark,
          modifier =
            Modifier.align(Alignment.TopEnd)
              .padding(6.dp)
              .size(48.dp)
              .testTag("bookmark_button_${property.id}"),
        ) {
          Box(
            modifier =
              Modifier.size(36.dp)
                .clip(CircleShape)
                .background(extraColors.toastSurface.copy(alpha = 0.55f)),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = if (isBookmarked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
              contentDescription = stringResource(R.string.cd_bookmark_property),
              tint =
                if (isBookmarked) extraColors.goldAccent else MaterialTheme.colorScheme.onPrimary,
              modifier = Modifier.size(18.dp),
            )
          }
        }

        // Bottom-left Verified Appraiser Badge
        if (property.verified) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = extraColors.goldAccent,
            shadowElevation = 2.dp,
            modifier = Modifier.align(Alignment.BottomStart).padding(12.dp),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Filled.Verified,
                contentDescription = null,
                tint = extraColors.onGoldAccent,
                modifier = Modifier.size(13.dp),
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = stringResource(R.string.verified_appraiser_badge),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.ExtraBold,
                color = extraColors.onGoldAccent,
              )
            }
          }
        }
      }

      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = property.title,
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Filled.LocationOn,
            contentDescription = null,
            tint = extraColors.goldAccent,
            modifier = Modifier.size(15.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = property.location,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        HorizontalDivider(
          modifier = Modifier.padding(vertical = 12.dp),
          color = extraColors.cardBorder,
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(14.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          if (property.beds > 0) {
            SpecInlineItem(icon = Icons.Filled.Bed, label = "${property.beds} Beds")
          }
          if (property.baths > 0) {
            SpecInlineItem(icon = Icons.Filled.Bathtub, label = "${property.baths} Baths")
          }
          SpecInlineItem(icon = Icons.Filled.SquareFoot, label = "${property.area} m²")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.Bottom) {
            Text(
              text = formatUsd(property.price),
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.primary,
            )
            if (priceSuffix.isNotEmpty()) {
              Text(
                text = priceSuffix,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 2.dp, bottom = 2.dp),
              )
            }
          }

          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier =
              Modifier.clip(RoundedCornerShape(12.dp))
                .clickable(onClick = onCardClick)
                .padding(horizontal = 14.dp, vertical = 8.dp),
          ) {
            Text(
              text = stringResource(R.string.btn_details),
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun SpecInlineItem(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = MaterialTheme.colorScheme.primary,
      modifier = Modifier.size(16.dp),
    )
    Spacer(modifier = Modifier.width(4.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
  }
}

@Composable
fun PropertyArtworkImage(imageUrl: String, title: String, modifier: Modifier = Modifier) {
  val extraColors = LocalGuriXalColors.current
  SubcomposeAsyncImage(
    model = imageUrl,
    contentDescription = title,
    contentScale = ContentScale.Crop,
    modifier = modifier,
    loading = { ArchitecturalGradientCanvas(modifier = Modifier.fillMaxSize()) },
    error = { ArchitecturalGradientCanvas(modifier = Modifier.fillMaxSize()) },
  )
}

@Composable
private fun ArchitecturalGradientCanvas(modifier: Modifier = Modifier) {
  val extraColors = LocalGuriXalColors.current
  val primary = MaterialTheme.colorScheme.primary
  Canvas(modifier = modifier) {
    drawRect(
      brush =
        Brush.linearGradient(
          colors = listOf(extraColors.headerGradientStart, primary, extraColors.headerGradientEnd),
          start = Offset.Zero,
          end = Offset(size.width, size.height),
        )
    )
    // Subtle architectural geometric accent arcs using DrawScope size
    drawCircle(
      color = extraColors.goldAccent.copy(alpha = 0.16f),
      radius = size.minDimension * 0.48f,
      center = Offset(size.width * 0.82f, size.height * 0.25f),
    )
  }
}

@Composable
fun MurabahaMortgageCalculatorCard(
  state: MortgageState,
  onPriceChange: (String) -> Unit,
  onDownChange: (String) -> Unit,
  onYearsChange: (Int) -> Unit,
  onPrequalifyClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val extraColors = LocalGuriXalColors.current
  var yearsMenuExpanded by remember { mutableStateOf(false) }

  Card(
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, extraColors.cardBorder),
    modifier = modifier.fillMaxWidth().testTag("mortgage_calculator_card"),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier =
            Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(extraColors.goldContainer),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Filled.Calculate,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.size(20.dp),
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = stringResource(R.string.calc_title),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = stringResource(R.string.calc_subtitle),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
          value = state.priceText,
          onValueChange = onPriceChange,
          label = { Text(stringResource(R.string.calc_home_price)) },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1f).testTag("calc_price_input"),
        )
        OutlinedTextField(
          value = state.downPaymentText,
          onValueChange = onDownChange,
          label = { Text(stringResource(R.string.calc_down_payment)) },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1f).testTag("calc_down_input"),
        )
      }

      Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Box(modifier = Modifier.weight(1f)) {
          OutlinedButton(
            onClick = { yearsMenuExpanded = true },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp).testTag("calc_years_selector"),
          ) {
            Text(
              text = "${state.years} Sanadood",
              style = MaterialTheme.typography.labelLarge,
            )
          }
          DropdownMenu(
            expanded = yearsMenuExpanded,
            onDismissRequest = { yearsMenuExpanded = false },
          ) {
            listOf(5, 10, 15).forEach { yrs ->
              DropdownMenuItem(
                text = { Text("$yrs Sanadood") },
                onClick = {
                  onYearsChange(yrs)
                  yearsMenuExpanded = false
                },
              )
            }
          }
        }

        Surface(
          shape = RoundedCornerShape(14.dp),
          color = MaterialTheme.colorScheme.surfaceVariant,
          modifier = Modifier.weight(1f).height(52.dp),
        ) {
          Column(
            modifier = Modifier.padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.Center,
          ) {
            Text(
              text = stringResource(R.string.calc_profit_label),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
              text = stringResource(R.string.calc_profit_value),
              style = MaterialTheme.typography.labelLarge,
              color = MaterialTheme.colorScheme.onSurface,
            )
          }
        }
      }

      Surface(
        shape = RoundedCornerShape(18.dp),
        color = extraColors.headerGradientStart,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(
          modifier = Modifier.padding(14.dp).fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = stringResource(R.string.calc_estimated_monthly).uppercase(),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.75f),
            )
            Text(
              text = "${formatUsd(state.estimatedMonthlyUsd, decimals = 2)} /mo",
              style = MaterialTheme.typography.titleLarge,
              color = extraColors.goldAccent,
              modifier = Modifier.testTag("calc_monthly_result"),
            )
          }

          Button(
            onClick = onPrequalifyClick,
            shape = RoundedCornerShape(12.dp),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = extraColors.goldAccent,
                contentColor = extraColors.onGoldAccent,
              ),
            modifier = Modifier.height(48.dp).testTag("calc_prequalify_button"),
          ) {
            Text(
              text = stringResource(R.string.calc_prequalify),
              style = MaterialTheme.typography.labelLarge,
            )
          }
        }
      }
    }
  }
}
