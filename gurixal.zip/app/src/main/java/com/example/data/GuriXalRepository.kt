package com.example.data

import android.content.Context
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class GuriXalRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth,
) {
  constructor(
    context: Context
  ) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    ),
    Firebase.auth,
  )

  private fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException(
        "User must be signed in with Google before writing to Firestore."
      )
  }

  // --- 1. Marketplace Properties ---

  fun observePublishedProperties(): Flow<List<PropertyListing>> {
    val path = "properties"
    return db
      .collection(path)
      .whereEqualTo("status", "published")
      .snapshots()
      .map { snapshot ->
        snapshot
          .toObjects(PropertyListing::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        throw error
      }
  }

  suspend fun createProperty(
    title: String,
    type: String,
    category: String,
    district: String,
    location: String,
    price: Double,
    beds: Long,
    baths: Long,
    area: Long,
    imageUrl: String,
    description: String,
    verified: Boolean = true,
  ): Result<String> = runCatching {
    val uid = requireUserId()
    val docId = "prop_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val docRef = db.collection("properties").document(docId)
    val payload =
      mapOf(
        "ownerId" to uid,
        "title" to title.trim(),
        "type" to type,
        "category" to category,
        "district" to district,
        "location" to location.trim(),
        "price" to price,
        "beds" to beds,
        "baths" to baths,
        "area" to area,
        "imageUrl" to imageUrl,
        "description" to description.trim(),
        "verified" to verified,
        "status" to "published",
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp(),
      )
    try {
      docRef.set(payload).await()
      docId
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      throw e
    }
  }

  suspend fun archiveProperty(propertyId: String): Result<Unit> = runCatching {
    requireUserId()
    val docRef = db.collection("properties").document(propertyId)
    try {
      docRef
        .update(mapOf("status" to "archived", "updatedAt" to FieldValue.serverTimestamp()))
        .await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      throw e
    }
  }

  // --- 2. Saved Bookmarks ---

  fun observeBookmarks(userId: String): Flow<List<Bookmark>> {
    val path = "users/$userId/bookmarks"
    return db
      .collection("users")
      .document(userId)
      .collection("bookmarks")
      .whereEqualTo("userId", userId)
      .snapshots()
      .map { snapshot ->
        snapshot.toObjects(Bookmark::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        throw error
      }
  }

  suspend fun toggleBookmark(
    propertyId: String,
    propertyTitle: String,
    currentlyBookmarked: Boolean,
  ): Result<Boolean> = runCatching {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("bookmarks").document(propertyId)
    try {
      if (currentlyBookmarked) {
        docRef.delete().await()
        false
      } else {
        val payload =
          mapOf(
            "userId" to uid,
            "propertyId" to propertyId,
            "propertyTitle" to propertyTitle.take(120),
            "createdAt" to FieldValue.serverTimestamp(),
          )
        docRef.set(payload).await()
        true
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      val op = if (currentlyBookmarked) OperationType.DELETE else OperationType.CREATE
      handleFirestoreError(e, op, docRef.path)
      throw e
    }
  }

  // --- 3. Digital Lease Contracts ---

  fun observeContracts(userId: String): Flow<List<LeaseContract>> {
    val path = "users/$userId/contracts"
    return db
      .collection("users")
      .document(userId)
      .collection("contracts")
      .whereEqualTo("userId", userId)
      .snapshots()
      .map { snapshot ->
        snapshot
          .toObjects(LeaseContract::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        throw error
      }
  }

  suspend fun signLeaseContract(
    propertyTitle: String,
    tenantName: String,
    paymentMethod: String,
    monthlyRent: Double,
    signaturePointsCount: Long,
    signaturePath: String,
  ): Result<String> = runCatching {
    val uid = requireUserId()
    val docId = "lease_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val docRef = db.collection("users").document(uid).collection("contracts").document(docId)
    val payload =
      mapOf(
        "userId" to uid,
        "propertyTitle" to propertyTitle.trim().take(120),
        "tenantName" to tenantName.trim().take(100),
        "paymentMethod" to paymentMethod,
        "monthlyRent" to monthlyRent,
        "signaturePointsCount" to signaturePointsCount,
        "signaturePath" to signaturePath.take(4000),
        "status" to "signed",
        "createdAt" to FieldValue.serverTimestamp(),
      )
    try {
      docRef.set(payload).await()
      docId
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      throw e
    }
  }

  suspend fun getContractById(targetUserId: String, contractId: String): Result<LeaseContract?> =
    runCatching {
      val docRef =
        db.collection("users").document(targetUserId).collection("contracts").document(contractId)
      try {
        docRef
          .get()
          .await()
          .toObject(LeaseContract::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        handleFirestoreError(e, OperationType.GET, docRef.path)
        throw e
      }
    }

  // --- 4. Mobile Money Payments ---

  fun observePayments(userId: String): Flow<List<PaymentRecord>> {
    val path = "users/$userId/payments"
    return db
      .collection("users")
      .document(userId)
      .collection("payments")
      .whereEqualTo("userId", userId)
      .snapshots()
      .map { snapshot ->
        snapshot
          .toObjects(PaymentRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        throw error
      }
  }

  suspend fun recordMobilePayment(
    payerName: String,
    propertyLabel: String,
    provider: String,
    rawPhone: String,
    amount: Double,
  ): Result<String> = runCatching {
    val uid = requireUserId()
    val docId = "pay_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val docRef = db.collection("users").document(uid).collection("payments").document(docId)
    val digits = rawPhone.filter { it.isDigit() }
    val tail = digits.takeLast(4).ifEmpty { "0000" }
    val masked = "+252 ** *** $tail"
    val prefix =
      when (provider) {
        "EVC Plus" -> "EVC"
        "Premier Wallet" -> "PRM"
        "SAHAL" -> "SHL"
        "Zaad" -> "ZAD"
        else -> "GXL"
      }
    val refCode = "#$prefix-${(10000..99999).random()}"
    val payload =
      mapOf(
        "userId" to uid,
        "payerName" to payerName.trim().take(100),
        "propertyLabel" to propertyLabel.trim().take(120),
        "provider" to provider,
        "phoneMasked" to masked,
        "referenceCode" to refCode,
        "amount" to amount,
        "status" to "completed",
        "createdAt" to FieldValue.serverTimestamp(),
      )
    try {
      docRef.set(payload).await()
      refCode
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      throw e
    }
  }

  // --- 5. Maintenance Tickets ---

  fun observeMaintenanceTickets(userId: String): Flow<List<MaintenanceTicket>> {
    val path = "users/$userId/maintenance_tickets"
    return db
      .collection("users")
      .document(userId)
      .collection("maintenance_tickets")
      .whereEqualTo("userId", userId)
      .snapshots()
      .map { snapshot ->
        snapshot
          .toObjects(
            MaintenanceTicket::class.java,
            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
          )
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .catch { error ->
        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
        throw error
      }
  }

  suspend fun createMaintenanceTicket(
    title: String,
    unitLabel: String,
    description: String,
    fundiName: String,
    status: String = "in_progress",
  ): Result<String> = runCatching {
    val uid = requireUserId()
    val docId = "tkt_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val docRef =
      db.collection("users").document(uid).collection("maintenance_tickets").document(docId)
    val payload =
      mapOf(
        "userId" to uid,
        "title" to title.trim().take(120),
        "unitLabel" to unitLabel.trim().take(100),
        "description" to description.trim().take(600),
        "fundiName" to fundiName.trim().take(100),
        "status" to status,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp(),
      )
    try {
      docRef.set(payload).await()
      docId
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      throw e
    }
  }

  suspend fun updateTicketStatus(ticketId: String, newStatus: String): Result<Unit> = runCatching {
    val uid = requireUserId()
    val docRef =
      db.collection("users").document(uid).collection("maintenance_tickets").document(ticketId)
    try {
      docRef
        .update(mapOf("status" to newStatus, "updatedAt" to FieldValue.serverTimestamp()))
        .await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      throw e
    }
  }

  // --- Initial Starter Seed for First-Time Workspace ---

  suspend fun seedInitialMogadishuDataIfEmpty(userId: String) {
    try {
      val existingProps =
        db.collection("properties").whereEqualTo("status", "published").limit(1).get().await()
      if (existingProps.isEmpty) {
        createProperty(
          title = "Oceanview Apartment 4B",
          type = "Rent",
          category = "Apartment",
          district = "Abdiaziz",
          location = "Abdiaziz, Near Lido Beach, Mogadishu",
          price = 450.0,
          beds = 3L,
          baths = 2L,
          area = 140L,
          imageUrl =
            "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=800&q=80",
          description =
            "Gurigan wuxuu leeyahay koronto 24 saac ah oo Solar ah, aragtida xeebta Liido, amni sugan, iyo marin biyood joogto ah.",
          verified = true,
        )
        val villaResult =
          createProperty(
            title = "Luxury Commercial Villa",
            type = "Buy",
            category = "Villa",
            district = "Hodan",
            location = "Hodan, Digfer Road, Mogadishu",
            price = 185000.0,
            beds = 6L,
            baths = 5L,
            area = 450L,
            imageUrl =
              "https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=800&q=80",
            description =
              "Villa casri ah oo ku taalla wadada Digfer ee Hodan. Waxay leedahay barxad baabuur, nidaamka Solar, iyo dukumiinti sharci 100% ah.",
            verified = true,
          )
        createProperty(
          title = "Modern Duplex Suite",
          type = "Rent",
          category = "Apartment",
          district = "Wadajir",
          location = "Wadajir, Airport Road, Mogadishu",
          price = 700.0,
          beds = 4L,
          baths = 3L,
          area = 210L,
          imageUrl =
            "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80",
          description =
            "Duplex casri ah oo u dhow garoonka diyaaradaha Aadan Cadde, leh ilaalo 24/7 ah, matoor kayd ah, iyo qolal waasac ah.",
          verified = true,
        )
        createProperty(
          title = "Prime Commercial Coast Plot",
          type = "Buy",
          category = "Land",
          district = "Karan",
          location = "Karan Beachfront, Mogadishu",
          price = 45000.0,
          beds = 0L,
          baths = 0L,
          area = 600L,
          imageUrl =
            "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=800&q=80",
          description =
            "Dhul ganacsi oo cabbirkiisu yahay 600m² kuna yaalla xeebta Kaaraan. Dhammaan warqadaha milkiyadda waa la hubiyay.",
          verified = true,
        )
        villaResult.getOrNull()?.let { id ->
          toggleBookmark(id, "Luxury Commercial Villa", currentlyBookmarked = false)
        }
      }

      val existingPayments =
        db
          .collection("users")
          .document(userId)
          .collection("payments")
          .whereEqualTo("userId", userId)
          .limit(1)
          .get()
          .await()
      if (existingPayments.isEmpty) {
        recordMobilePayment(
          payerName = "Eng. Jama Hassan",
          propertyLabel = "Apt 3A - Lido Beach",
          provider = "EVC Plus",
          rawPhone = "615884920",
          amount = 600.0,
        )
        recordMobilePayment(
          payerName = "Amina Mohamed",
          propertyLabel = "Villa 12 - Hodan",
          provider = "Premier Wallet",
          rawPhone = "615229104",
          amount = 1500.0,
        )
      }

      val existingTickets =
        db
          .collection("users")
          .document(userId)
          .collection("maintenance_tickets")
          .whereEqualTo("userId", userId)
          .limit(1)
          .get()
          .await()
      if (existingTickets.isEmpty) {
        createMaintenanceTicket(
          title = "Tubada Biyaha ee Musqusha",
          unitLabel = "Guri 4B, Abdiaziz",
          description =
            "Guri 4B, Abdiaziz. U baahan bedelaad tubbada biyaha nidaamka matoorka.",
          fundiName = "Dahir Plumbing Service",
          status = "in_progress",
        )
        createMaintenanceTicket(
          title = "Kormeerka Solar Inverter-ka",
          unitLabel = "Villa 12, Hodan",
          description = "Hubinta batteriga kaydka qorraxda iyo bedelaadda fiilada.",
          fundiName = "Banadir Solar Tech",
          status = "open",
        )
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "seedInitialMogadishuDataIfEmpty")
    }
  }
}
