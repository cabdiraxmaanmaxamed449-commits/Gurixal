package com.example.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class PropertyListing(
  @DocumentId val id: String = "",
  val ownerId: String = "",
  val title: String = "",
  val type: String = "Rent",
  val category: String = "Apartment",
  val district: String = "Hodan",
  val location: String = "",
  val price: Double = 0.0,
  val beds: Long = 0L,
  val baths: Long = 0L,
  val area: Long = 100L,
  val imageUrl: String = "",
  val description: String = "",
  val verified: Boolean = true,
  val status: String = "published",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class Bookmark(
  @DocumentId val id: String = "",
  val userId: String = "",
  val propertyId: String = "",
  val propertyTitle: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class LeaseContract(
  @DocumentId val id: String = "",
  val userId: String = "",
  val propertyTitle: String = "",
  val tenantName: String = "",
  val paymentMethod: String = "EVC Plus",
  val monthlyRent: Double = 0.0,
  val signaturePointsCount: Long = 0L,
  val signaturePath: String = "",
  val status: String = "signed",
  @ServerTimestamp val createdAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class PaymentRecord(
  @DocumentId val id: String = "",
  val userId: String = "",
  val payerName: String = "",
  val propertyLabel: String = "",
  val provider: String = "EVC Plus",
  val phoneMasked: String = "",
  val referenceCode: String = "",
  val amount: Double = 0.0,
  val status: String = "completed",
  @ServerTimestamp val createdAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class MaintenanceTicket(
  @DocumentId val id: String = "",
  val userId: String = "",
  val title: String = "",
  val unitLabel: String = "",
  val description: String = "",
  val fundiName: String = "",
  val status: String = "in_progress",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

sealed interface UiState<out T> {
  data object Loading : UiState<Nothing>

  data class Success<T>(val data: T) : UiState<T>

  data class Error(val message: String) : UiState<Nothing>
}
