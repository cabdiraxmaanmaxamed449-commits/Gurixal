# GuriXal Platform — Firestore Security Specification (Phase 0 TDD)

## 1. Data Invariants
1. **Authentication Mandatory**: Zero unauthenticated reads or writes across all collections (`request.auth != null`).
2. **Marketplace Listing Integrity (`/properties/{propertyId}`)**:
   - Listings can only be read (`get`/`list`) if `status == 'published'` or `ownerId == request.auth.uid`.
   - Listings can only be created with `ownerId == request.auth.uid` and valid Mogadishu district/category/type enums, bounded strings, positive price/area, and server timestamps.
   - Only the original `ownerId` can update or delete a property; `ownerId`, `verified`, and `createdAt` are immutable; `'archived'` is a terminal status.
3. **Strict Multi-Tenant User Isolation (`/users/{userId}/...`)**:
   - Subcollections `bookmarks`, `contracts`, `payments`, and `maintenance_tickets` strictly require `request.auth.uid == userId` and `resource.data.userId == request.auth.uid`.
   - `contracts` and `payments` are immutable append-only legal/financial records (`allow update, delete: if false`).
   - `bookmarks` are immutable toggle records (`allow update: if false`, create/delete only).
   - `maintenance_tickets` enforce terminal state locking once `status == 'resolved'`.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated Marketplace Scrape**: Unauthenticated `list` on `/properties` -> Denied.
2. **Unfiltered Marketplace List**: Authenticated `list` on `/properties` without `where('status', '==', 'published')` -> Denied (rules are not filters).
3. **Identity Spoofing on Property Create**: Alice attempts to create `/properties/prop_1` with `ownerId: "bob_456"` -> Denied.
4. **Shadow/Ghost Field Injection**: Alice creates `/properties/prop_1` with extra key `isAdminFeatured: true` -> Denied by `hasOnly()`.
5. **Cross-User Property Takeover**: Bob attempts to update or delete Alice's `/properties/prop_1` -> Denied.
6. **Privilege Escalation (`verified` Mutation)**: Owner attempts to mutate `verified` from `false` to `true` on update -> Denied by `affectedKeys().hasOnly()`.
7. **Terminal State Bypass on Archived Property**: Owner attempts to update a property already in `status == 'archived'` -> Denied.
8. **Cross-User PII Leak on Lease Contracts**: Bob attempts `get` or `list` on `/users/alice_123/contracts` -> Denied.
9. **Forged Empty Signature on Digital Lease**: Alice submits contract with `signaturePointsCount: 0` or empty `signaturePath` -> Denied by `isValidContract()`.
10. **Immutable Contract Tampering**: Alice attempts `update` or `delete` on an already signed contract -> Denied.
11. **Negative/Zero Amount Payment Poisoning**: Alice submits payment with `amount: -500` or unsupported provider `"Crypto"` -> Denied by `isValidPayment()`.
12. **Terminal State Bypass on Resolved Maintenance Ticket**: Alice attempts to reopen a ticket whose `status` is already `'resolved'` -> Denied.
